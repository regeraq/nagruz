# Скрипт запуска сервера разработки
# Переход в корневую директорию проекта (скрипт должен быть в scripts/)
$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location (Split-Path -Parent $scriptPath)

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Запуск сервера разработки" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Поиск Node.js
$nodePaths = @(
    "C:\Program Files\nodejs\node.exe",
    "$env:LOCALAPPDATA\Programs\nodejs\node.exe",
    "${env:ProgramFiles(x86)}\nodejs\node.exe"
)

$nodePath = $null
foreach ($path in $nodePaths) {
    if (Test-Path $path) {
        $nodePath = Split-Path $path
        Write-Host "[OK] Node.js найден: $nodePath" -ForegroundColor Green
        $env:PATH = "$nodePath;$env:PATH"
        break
    }
}

# Проверка через PATH
if (-not $nodePath) {
    try {
        $nodeVersion = node --version 2>$null
        if ($nodeVersion) {
            Write-Host "[OK] Node.js найден в PATH: $nodeVersion" -ForegroundColor Green
            $nodePath = "PATH"
        }
    } catch {
        # Игнорируем ошибку
    }
}

if (-not $nodePath) {
    Write-Host "[ОШИБКА] Node.js не найден!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Пожалуйста, установите Node.js с https://nodejs.org/" -ForegroundColor Yellow
    Write-Host "Или добавьте Node.js в PATH системы" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Нажмите Enter для выхода"
    exit 1
}

# Проверка зависимостей
Write-Host ""
Write-Host "Проверка зависимостей..." -ForegroundColor Cyan
if (-not (Test-Path "node_modules")) {
    Write-Host "Установка зависимостей (это может занять несколько минут)..." -ForegroundColor Yellow
    npm install
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[ОШИБКА] Не удалось установить зависимости" -ForegroundColor Red
        Read-Host "Нажмите Enter для выхода"
        exit 1
    }
} else {
    Write-Host "[OK] Зависимости уже установлены" -ForegroundColor Green
}

# Запуск сервера
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Запуск сервера..." -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Сервер будет доступен по адресу: http://localhost:5000" -ForegroundColor Green
Write-Host "Для остановки нажмите Ctrl+C" -ForegroundColor Yellow
Write-Host ""

$env:NODE_ENV = "development"
npm run dev

