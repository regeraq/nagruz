export default function Applications() {
  return (
    <div className="container mx-auto px-4 py-8 pt-24">
      <h1 className="text-4xl font-bold mb-8">Применение</h1>
      <div className="prose max-w-none">
        <p>Страница с информацией о применении товаров</p>
      </div>
    </div>
  );
}

