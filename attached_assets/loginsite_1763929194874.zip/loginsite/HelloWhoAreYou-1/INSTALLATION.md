# Инструкция по установке и запуску

## Установка зависимостей

Перед запуском необходимо установить дополнительные зависимости для аутентификации:

```bash
npm install bcryptjs jsonwebtoken @types/bcryptjs @types/jsonwebtoken
```

Для OAuth (опционально, если планируется использовать):
```bash
npm install passport-google-oauth20 passport-vkontakte @types/passport-google-oauth20
```

## Переменные окружения

Создайте файл `.env` в корне проекта:

```env
NODE_ENV=development
PORT=5000
JWT_SECRET=your-super-secret-jwt-key-change-in-production
JWT_REFRESH_SECRET=your-super-secret-refresh-key-change-in-production
DATABASE_URL=your_database_url
RESEND_API_KEY=your_resend_api_key
OWNER_EMAIL=owner@example.com

# OAuth (опционально)
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret
VK_APP_ID=your_vk_app_id
VK_APP_SECRET=your_vk_app_secret
```

## Запуск

```bash
npm install
npm run dev
```

Приложение будет доступно на http://localhost:5000

## Предустановленный админ-аккаунт

При первом запуске автоматически создается админ-аккаунт:
- Email: rostext@gmail.com
- Пароль: 125607
- Роль: superadmin

## Структура проекта

- `server/` - Backend (Express)
  - `auth.ts` - Функции аутентификации (JWT, bcrypt)
  - `routes/auth.ts` - Маршруты аутентификации
  - `middleware/auth.ts` - Middleware для проверки авторизации
  - `middleware/bruteForce.ts` - Защита от брут-форс атак
  - `initAdmin.ts` - Инициализация админ-аккаунта
  - `storage.ts` - Хранилище данных (in-memory, можно заменить на БД)

- `client/src/` - Frontend (React)
  - `pages/` - Страницы приложения
    - `login.tsx` - Страница входа
    - `register.tsx` - Страница регистрации
    - `profile.tsx` - Личный кабинет
    - `admin.tsx` - Админ-панель
    - `specifications.tsx` - Характеристики
    - `applications.tsx` - Применение
    - `documentation.tsx` - Документация
  - `components/navigation.tsx` - Навигационная панель

- `shared/schema.ts` - Схема базы данных (Drizzle ORM)

## Особенности реализации

1. **Аутентификация**: JWT токены (access + refresh), защита от брут-форс атак
2. **Безопасность**: CSRF защита, валидация входных данных, secure cookies
3. **Навигация**: Адаптивная, с поддержкой авторизованных/неавторизованных пользователей
4. **Админ-панель**: Базовая структура с вкладками для управления товарами, пользователями, аналитикой, контентом и настройками
5. **Личный кабинет**: Профиль, история заказов, избранное, уведомления

## Следующие шаги

1. Реализовать OAuth провайдеры (Google, Apple, VK)
2. Добавить полноценный CRUD для товаров в админ-панели
3. Реализовать управление пользователями с RBAC
4. Добавить аналитику и графики
5. Реализовать систему уведомлений
6. Добавить мультиязычность
7. Мигрировать с MemStorage на реальную БД (PostgreSQL через Drizzle)

