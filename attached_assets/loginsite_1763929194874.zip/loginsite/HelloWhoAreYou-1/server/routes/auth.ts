import type { Express } from "express";
import express from "express";
import { z } from "zod";
import { storage } from "../storage";
import {
  hashPassword,
  verifyPassword,
  generateTokenPair,
  generateEmailVerificationToken,
  generatePhoneVerificationCode,
  verifyRefreshToken,
} from "../auth";
import { authenticate, optionalAuthenticate } from "../middleware/auth";
import { bruteForceProtection, recordLoginAttempt } from "../middleware/bruteForce";
import { rateLimiters } from "../rateLimiter";
import { csrfProtection } from "../csrf";
import { sanitizeInput } from "../security";

const router = express.Router();

// Registration schema
const registerSchema = z.object({
  email: z.string().email("Введите корректный email"),
  password: z.string().min(8, "Пароль должен содержать минимум 8 символов"),
  firstName: z.string().min(2, "Имя должно содержать минимум 2 символа").optional(),
  lastName: z.string().min(2, "Фамилия должна содержать минимум 2 символа").optional(),
  phone: z.string().min(10, "Введите корректный номер телефона").optional(),
});

// Login schema
const loginSchema = z.object({
  email: z.string().email("Введите корректный email"),
  password: z.string().min(1, "Пароль обязателен"),
});

// Phone verification schema
const phoneVerificationSchema = z.object({
  phone: z.string().min(10, "Введите корректный номер телефона"),
  code: z.string().length(6, "Код должен содержать 6 цифр"),
});

/**
 * POST /api/auth/register
 * Register new user with email/password
 */
router.post(
  "/register",
  csrfProtection,
  bruteForceProtection,
  rateLimiters.auth,
  async (req, res) => {
    try {
      const validatedData = registerSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(409).json({
          success: false,
          message: "Пользователь с таким email уже существует",
        });
      }

      // Check phone if provided
      if (validatedData.phone) {
        const existingPhoneUser = await storage.getUserByPhone(validatedData.phone);
        if (existingPhoneUser) {
          return res.status(409).json({
            success: false,
            message: "Пользователь с таким номером телефона уже существует",
          });
        }
      }

      // Hash password
      const passwordHash = await hashPassword(validatedData.password);
      
      // Generate email verification token
      const emailVerificationToken = generateEmailVerificationToken();

      // Create user
      const user = await storage.createUser({
        email: validatedData.email,
        password: validatedData.password,
        firstName: validatedData.firstName,
        lastName: validatedData.lastName,
        phone: validatedData.phone,
        passwordHash,
        emailVerificationToken,
        isEmailVerified: false,
      });

      // Generate tokens
      const tokens = generateTokenPair(user);

      // Create session
      await storage.createSession({
        userId: user.id,
        refreshToken: tokens.refreshToken,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
        ipAddress: req.ip || req.socket.remoteAddress || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });

      // TODO: Send email verification email

      res.status(201).json({
        success: true,
        message: "Регистрация успешна. Проверьте email для подтверждения.",
        user: {
          id: user.id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
          isEmailVerified: user.isEmailVerified,
        },
        tokens,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          success: false,
          message: "Ошибка валидации данных",
          errors: error.errors,
        });
      }
      
      console.error("Registration error:", error);
      res.status(500).json({
        success: false,
        message: "Ошибка при регистрации",
      });
    }
  }
);

/**
 * POST /api/auth/login
 * Login with email/password
 */
router.post(
  "/login",
  csrfProtection,
  bruteForceProtection,
  rateLimiters.auth,
  async (req, res) => {
    try {
      const validatedData = loginSchema.parse(req.body);
      const ipAddress = req.ip || req.socket.remoteAddress || "unknown";

      // Get user
      const user = await storage.getUserByEmail(validatedData.email);
      
      if (!user) {
        await recordLoginAttempt(validatedData.email, ipAddress, false);
        return res.status(401).json({
          success: false,
          message: "Неверный email или пароль",
        });
      }

      // Check if user is blocked
      if (user.isBlocked) {
        return res.status(403).json({
          success: false,
          message: "Ваш аккаунт заблокирован",
        });
      }

      // Verify password
      if (!user.passwordHash) {
        await recordLoginAttempt(validatedData.email, ipAddress, false);
        return res.status(401).json({
          success: false,
          message: "Неверный email или пароль",
        });
      }

      const isPasswordValid = await verifyPassword(validatedData.password, user.passwordHash);
      
      if (!isPasswordValid) {
        await recordLoginAttempt(validatedData.email, ipAddress, false);
        return res.status(401).json({
          success: false,
          message: "Неверный email или пароль",
        });
      }

      // Update last login
      await storage.updateUser(user.id, { lastLoginAt: new Date() });

      // Record successful login
      await recordLoginAttempt(validatedData.email, ipAddress, true);

      // Generate tokens
      const tokens = generateTokenPair(user);

      // Create session
      await storage.createSession({
        userId: user.id,
        refreshToken: tokens.refreshToken,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
        ipAddress,
        userAgent: req.headers["user-agent"] || undefined,
      });

      res.json({
        success: true,
        message: "Вход выполнен успешно",
        user: {
          id: user.id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
          isEmailVerified: user.isEmailVerified,
        },
        tokens,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          success: false,
          message: "Ошибка валидации данных",
          errors: error.errors,
        });
      }
      
      console.error("Login error:", error);
      res.status(500).json({
        success: false,
        message: "Ошибка при входе",
      });
    }
  }
);

/**
 * POST /api/auth/refresh
 * Refresh access token using refresh token
 */
router.post("/refresh", rateLimiters.auth, async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken || typeof refreshToken !== "string") {
      return res.status(400).json({
        success: false,
        message: "Refresh token не предоставлен",
      });
    }

    // Verify refresh token
    const payload = verifyRefreshToken(refreshToken);
    if (!payload) {
      return res.status(401).json({
        success: false,
        message: "Недействительный refresh token",
      });
    }

    // Check session
    const session = await storage.getSessionByRefreshToken(refreshToken);
    if (!session || session.expiresAt < new Date()) {
      return res.status(401).json({
        success: false,
        message: "Сессия истекла",
      });
    }

    // Get user
    const user = await storage.getUserById(payload.userId);
    if (!user || user.isBlocked) {
      return res.status(401).json({
        success: false,
        message: "Пользователь не найден или заблокирован",
      });
    }

    // Generate new access token
    const tokens = generateTokenPair(user);

    // Update session with new refresh token
    await storage.deleteSession(session.id);
    await storage.createSession({
      userId: user.id,
      refreshToken: tokens.refreshToken,
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      ipAddress: session.ipAddress || undefined,
      userAgent: session.userAgent || undefined,
    });

    res.json({
      success: true,
      tokens,
    });
  } catch (error) {
    console.error("Refresh token error:", error);
    res.status(500).json({
      success: false,
      message: "Ошибка при обновлении токена",
    });
  }
});

/**
 * POST /api/auth/logout
 * Logout user (delete session)
 */
router.post("/logout", authenticate, rateLimiters.auth, async (req: any, res) => {
  try {
    const { refreshToken } = req.body;

    if (refreshToken) {
      const session = await storage.getSessionByRefreshToken(refreshToken);
      if (session) {
        await storage.deleteSession(session.id);
      }
    }

    res.json({
      success: true,
      message: "Выход выполнен успешно",
    });
  } catch (error) {
    console.error("Logout error:", error);
    res.status(500).json({
      success: false,
      message: "Ошибка при выходе",
    });
  }
});

/**
 * GET /api/auth/me
 * Get current user info
 */
router.get("/me", authenticate, rateLimiters.general, async (req: any, res) => {
  try {
    const user = await storage.getUserById(req.user.id);
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: "Пользователь не найден",
      });
    }

    res.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        phone: user.phone,
        firstName: user.firstName,
        lastName: user.lastName,
        avatar: user.avatar,
        role: user.role,
        isEmailVerified: user.isEmailVerified,
        isPhoneVerified: user.isPhoneVerified,
        createdAt: user.createdAt,
      },
    });
  } catch (error) {
    console.error("Get user error:", error);
    res.status(500).json({
      success: false,
      message: "Ошибка при получении данных пользователя",
    });
  }
});

/**
 * POST /api/auth/verify-email
 * Verify email with token
 */
router.post(
  "/verify-email",
  csrfProtection,
  rateLimiters.auth,
  async (req, res) => {
    try {
      const { token } = req.body;

      if (!token || typeof token !== "string") {
        return res.status(400).json({
          success: false,
          message: "Токен не предоставлен",
        });
      }

      // Find user by verification token
      const users = await storage.getAllUsers();
      const user = users.find(u => u.emailVerificationToken === token);

      if (!user) {
        return res.status(404).json({
          success: false,
          message: "Недействительный токен подтверждения",
        });
      }

      // Update user
      await storage.updateUser(user.id, {
        isEmailVerified: true,
        emailVerificationToken: null,
      });

      res.json({
        success: true,
        message: "Email успешно подтвержден",
      });
    } catch (error) {
      console.error("Email verification error:", error);
      res.status(500).json({
        success: false,
        message: "Ошибка при подтверждении email",
      });
    }
  }
);

/**
 * POST /api/auth/send-phone-code
 * Send phone verification code
 */
router.post(
  "/send-phone-code",
  csrfProtection,
  rateLimiters.auth,
  authenticate,
  async (req: any, res) => {
    try {
      const { phone } = req.body;

      if (!phone || typeof phone !== "string") {
        return res.status(400).json({
          success: false,
          message: "Номер телефона не предоставлен",
        });
      }

      const sanitizedPhone = sanitizeInput(phone, 20);

      // Check if phone is already used
      const existingUser = await storage.getUserByPhone(sanitizedPhone);
      if (existingUser && existingUser.id !== req.user.id) {
        return res.status(409).json({
          success: false,
          message: "Этот номер телефона уже используется",
        });
      }

      // Generate verification code
      const code = generatePhoneVerificationCode();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

      // Update user
      await storage.updateUser(req.user.id, {
        phone: sanitizedPhone,
        phoneVerificationCode: code,
        phoneVerificationExpires: expiresAt,
      });

      // TODO: Send SMS with code

      res.json({
        success: true,
        message: "Код подтверждения отправлен на номер телефона",
      });
    } catch (error) {
      console.error("Send phone code error:", error);
      res.status(500).json({
        success: false,
        message: "Ошибка при отправке кода",
      });
    }
  }
);

/**
 * PATCH /api/auth/profile
 * Update user profile
 */
router.patch(
  "/profile",
  csrfProtection,
  rateLimiters.auth,
  authenticate,
  async (req: any, res) => {
    try {
      const updateSchema = z.object({
        firstName: z.string().min(2).optional().nullable(),
        lastName: z.string().min(2).optional().nullable(),
        phone: z.string().min(10).optional().nullable(),
      });

      const validatedData = updateSchema.parse(req.body);

      const updatedUser = await storage.updateUser(req.user.id, validatedData);

      if (!updatedUser) {
        return res.status(404).json({
          success: false,
          message: "Пользователь не найден",
        });
      }

      res.json({
        success: true,
        message: "Профиль обновлен",
        user: {
          id: updatedUser.id,
          email: updatedUser.email,
          firstName: updatedUser.firstName,
          lastName: updatedUser.lastName,
          phone: updatedUser.phone,
          role: updatedUser.role,
          isEmailVerified: updatedUser.isEmailVerified,
          isPhoneVerified: updatedUser.isPhoneVerified,
        },
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          success: false,
          message: "Ошибка валидации данных",
          errors: error.errors,
        });
      }

      console.error("Update profile error:", error);
      res.status(500).json({
        success: false,
        message: "Ошибка при обновлении профиля",
      });
    }
  }
);

/**
 * POST /api/auth/verify-phone
 * Verify phone with code
 */
router.post(
  "/verify-phone",
  csrfProtection,
  rateLimiters.auth,
  authenticate,
  async (req: any, res) => {
    try {
      const validatedData = phoneVerificationSchema.parse(req.body);

      const user = await storage.getUserById(req.user.id);
      if (!user) {
        return res.status(404).json({
          success: false,
          message: "Пользователь не найден",
        });
      }

      if (user.phone !== validatedData.phone) {
        return res.status(400).json({
          success: false,
          message: "Номер телефона не совпадает",
        });
      }

      if (!user.phoneVerificationCode || !user.phoneVerificationExpires) {
        return res.status(400).json({
          success: false,
          message: "Код подтверждения не был отправлен",
        });
      }

      if (user.phoneVerificationExpires < new Date()) {
        return res.status(400).json({
          success: false,
          message: "Код подтверждения истек",
        });
      }

      if (user.phoneVerificationCode !== validatedData.code) {
        return res.status(400).json({
          success: false,
          message: "Неверный код подтверждения",
        });
      }

      // Update user
      await storage.updateUser(user.id, {
        isPhoneVerified: true,
        phoneVerificationCode: null,
        phoneVerificationExpires: null,
      });

      res.json({
        success: true,
        message: "Номер телефона успешно подтвержден",
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          success: false,
          message: "Ошибка валидации данных",
          errors: error.errors,
        });
      }

      console.error("Phone verification error:", error);
      res.status(500).json({
        success: false,
        message: "Ошибка при подтверждении номера телефона",
      });
    }
  }
);

export function registerAuthRoutes(app: Express): void {
  app.use("/api/auth", router);
}

