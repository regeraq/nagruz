import { 
  type ContactSubmission, 
  type InsertContactSubmission,
  type Product,
  type InsertProduct,
  type Order,
  type InsertOrder,
  type PromoCode,
  type InsertPromoCode,
  type User,
  type InsertUser,
  type Session,
  type InsertSession,
  type OAuthProvider,
  type InsertOAuthProvider,
  type Favorite,
  type InsertFavorite,
  type Notification,
  type InsertNotification,
  type ContentPage,
  type InsertContentPage,
  type LoginAttempt,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission>;
  getContactSubmissions(): Promise<ContactSubmission[]>;
  getContactSubmission(id: string): Promise<ContactSubmission | undefined>;
  
  getProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, updates: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;
  
  createOrder(order: InsertOrder): Promise<Order>;
  getOrders(): Promise<Order[]>;
  getOrdersByUserId(userId: string): Promise<Order[]>;
  getOrder(id: string): Promise<Order | undefined>;
  updateOrderStatus(id: string, status: string, paymentDetails?: string): Promise<Order | undefined>;
  
  validatePromoCode(code: string): Promise<PromoCode | undefined>;
  createPromoCode(promoCode: InsertPromoCode): Promise<PromoCode>;
  
  // User methods
  createUser(user: InsertUser & { passwordHash: string }): Promise<User>;
  getUserById(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByPhone(phone: string): Promise<User | undefined>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  deleteUser(id: string): Promise<boolean>;
  
  // Session methods
  createSession(session: InsertSession): Promise<Session>;
  getSessionByRefreshToken(refreshToken: string): Promise<Session | undefined>;
  deleteSession(id: string): Promise<boolean>;
  deleteUserSessions(userId: string): Promise<boolean>;
  
  // OAuth methods
  createOAuthProvider(provider: InsertOAuthProvider): Promise<OAuthProvider>;
  getOAuthProvider(provider: string, providerId: string): Promise<OAuthProvider | undefined>;
  getUserOAuthProviders(userId: string): Promise<OAuthProvider[]>;
  
  // Login attempts
  recordLoginAttempt(email: string, ipAddress: string, success: boolean): Promise<void>;
  
  // Favorites
  addFavorite(favorite: InsertFavorite): Promise<Favorite>;
  removeFavorite(userId: string, productId: string): Promise<boolean>;
  getUserFavorites(userId: string): Promise<Favorite[]>;
  isFavorite(userId: string, productId: string): Promise<boolean>;
  
  // Notifications
  createNotification(notification: InsertNotification): Promise<Notification>;
  getUserNotifications(userId: string, unreadOnly?: boolean): Promise<Notification[]>;
  markNotificationAsRead(id: string): Promise<boolean>;
  markAllNotificationsAsRead(userId: string): Promise<boolean>;
  deleteNotification(id: string): Promise<boolean>;
  
  // Content pages
  createContentPage(page: InsertContentPage): Promise<ContentPage>;
  getContentPage(id: string): Promise<ContentPage | undefined>;
  getContentPageBySlug(slug: string): Promise<ContentPage | undefined>;
  getAllContentPages(): Promise<ContentPage[]>;
  updateContentPage(id: string, updates: Partial<InsertContentPage>): Promise<ContentPage | undefined>;
  deleteContentPage(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private contactSubmissions: Map<string, ContactSubmission>;
  private products: Map<string, Product>;
  private orders: Map<string, Order>;
  private promoCodes: Map<string, PromoCode>;
  private users: Map<string, User>;
  private usersByEmail: Map<string, string>; // email -> userId
  private usersByPhone: Map<string, string>; // phone -> userId
  private sessions: Map<string, Session>;
  private sessionsByRefreshToken: Map<string, string>; // refreshToken -> sessionId
  private oauthProviders: Map<string, OAuthProvider>;
  private loginAttempts: Map<string, LoginAttempt>;
  private favorites: Map<string, Favorite>;
  private notifications: Map<string, Notification>;
  private contentPages: Map<string, ContentPage>;
  private contentPagesBySlug: Map<string, string>; // slug -> pageId

  constructor() {
    this.contactSubmissions = new Map();
    this.products = new Map();
    this.orders = new Map();
    this.promoCodes = new Map();
    this.users = new Map();
    this.usersByEmail = new Map();
    this.usersByPhone = new Map();
    this.sessions = new Map();
    this.sessionsByRefreshToken = new Map();
    this.oauthProviders = new Map();
    this.loginAttempts = new Map();
    this.favorites = new Map();
    this.notifications = new Map();
    this.contentPages = new Map();
    this.contentPagesBySlug = new Map();
    this.initializeProducts();
    this.initializePromoCodes();
  }

  private initializeProducts() {
    const now = new Date();
    const nu100: Product = {
      id: "nu-100",
      name: "НУ-100",
      description: "Профессиональное нагрузочное устройство для тестирования дизель-генераторов, газопоршневых и газотурбинных установок, ИБП и аккумуляторных батарей",
      price: "2850000.00",
      currency: "RUB",
      sku: "NU-100-2025",
      specifications: JSON.stringify({
        power: "100 кВт",
        steps: "20 ступеней",
        voltage: "AC/DC",
        acVoltage: "230-400 В",
        dcVoltage: "110-220 В",
        frequency: "50 Гц",
        phases: "3",
        cosφ: "0.99",
        cooling: "Воздушное принудительное"
      }),
      stock: 5,
      category: "Нагрузочные устройства",
      imageUrl: null,
      isActive: true,
      createdAt: now,
      updatedAt: now
    };
    
    const nu30: Product = {
      id: "nu-30",
      name: "НУ-30",
      description: "Компактное нагрузочное устройство для тестирования генераторов, ИБП и источников питания мощностью до 30 кВт",
      price: "980000.00",
      currency: "RUB",
      sku: "NU-30-2025",
      specifications: JSON.stringify({
        power: "30 кВт",
        steps: "6 ступеней",
        voltage: "AC/DC",
        acVoltage: "230-400 В",
        dcVoltage: "110-220 В",
        frequency: "50 Гц",
        phases: "3",
        cosφ: "0.99",
        cooling: "Воздушное принудительное"
      }),
      stock: 3,
      category: "Нагрузочные устройства",
      imageUrl: null,
      isActive: true,
      createdAt: now,
      updatedAt: now
    };

    this.products.set("nu-100", nu100);
    this.products.set("nu-30", nu30);
  }

  private initializePromoCodes() {
    const promo1: PromoCode = {
      id: randomUUID(),
      code: "WELCOME2025",
      discountPercent: 10,
      expiresAt: new Date("2025-12-31"),
      isActive: 1,
      createdAt: new Date()
    };
    
    const promo2: PromoCode = {
      id: randomUUID(),
      code: "INDUSTRIAL15",
      discountPercent: 15,
      expiresAt: new Date("2025-12-31"),
      isActive: 1,
      createdAt: new Date()
    };

    this.promoCodes.set(promo1.code.toUpperCase(), promo1);
    this.promoCodes.set(promo2.code.toUpperCase(), promo2);
  }

  async createContactSubmission(insertSubmission: InsertContactSubmission): Promise<ContactSubmission> {
    const id = randomUUID();
    const submission: ContactSubmission = {
      ...insertSubmission,
      id,
      fileName: insertSubmission.fileName ?? null,
      fileData: insertSubmission.fileData ?? null,
      createdAt: new Date(),
    };
    this.contactSubmissions.set(id, submission);
    return submission;
  }

  async getContactSubmissions(): Promise<ContactSubmission[]> {
    return Array.from(this.contactSubmissions.values());
  }

  async getContactSubmission(id: string): Promise<ContactSubmission | undefined> {
    return this.contactSubmissions.get(id);
  }

  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const product: Product = {
      ...insertProduct,
      currency: insertProduct.currency ?? "RUB",
      createdAt: new Date(),
    };
    this.products.set(product.id, product);
    return product;
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = randomUUID();
    const order: Order = {
      ...insertOrder,
      id,
      discountAmount: insertOrder.discountAmount ?? "0",
      paymentStatus: insertOrder.paymentStatus ?? "pending",
      promoCode: insertOrder.promoCode ?? null,
      customerName: insertOrder.customerName ?? null,
      customerEmail: insertOrder.customerEmail ?? null,
      customerPhone: insertOrder.customerPhone ?? null,
      paymentDetails: insertOrder.paymentDetails ?? null,
      reservedUntil: insertOrder.reservedUntil ?? null,
      createdAt: new Date(),
    };
    this.orders.set(id, order);
    return order;
  }

  async getOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }

  async getOrder(id: string): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async updateOrderStatus(id: string, status: string, paymentDetails?: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (order) {
      order.paymentStatus = status;
      if (paymentDetails) {
        order.paymentDetails = paymentDetails;
      }
      this.orders.set(id, order);
    }
    return order;
  }

  async validatePromoCode(code: string): Promise<PromoCode | undefined> {
    const promo = this.promoCodes.get(code.toUpperCase());
    if (!promo || promo.isActive !== 1) {
      return undefined;
    }
    
    if (promo.expiresAt && promo.expiresAt < new Date()) {
      return undefined;
    }
    
    return promo;
  }

  async createPromoCode(insertPromoCode: InsertPromoCode): Promise<PromoCode> {
    const id = randomUUID();
    const promoCode: PromoCode = {
      ...insertPromoCode,
      id,
      isActive: insertPromoCode.isActive ?? 1,
      expiresAt: insertPromoCode.expiresAt ?? null,
      createdAt: new Date(),
    };
    this.promoCodes.set(promoCode.code.toUpperCase(), promoCode);
    return promoCode;
  }

  // User methods
  async createUser(userData: InsertUser & { passwordHash: string }): Promise<User> {
    const id = randomUUID();
    const user: User = {
      id,
      email: userData.email,
      phone: userData.phone ?? null,
      passwordHash: userData.passwordHash,
      firstName: userData.firstName ?? null,
      lastName: userData.lastName ?? null,
      avatar: userData.avatar ?? null,
      role: (userData.role as any) ?? "user",
      isEmailVerified: userData.isEmailVerified ?? false,
      isPhoneVerified: userData.isPhoneVerified ?? false,
      isBlocked: userData.isBlocked ?? false,
      emailVerificationToken: userData.emailVerificationToken ?? null,
      phoneVerificationCode: userData.phoneVerificationCode ?? null,
      phoneVerificationExpires: userData.phoneVerificationExpires ?? null,
      lastLoginAt: userData.lastLoginAt ?? null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    
    this.users.set(id, user);
    this.usersByEmail.set(user.email.toLowerCase(), id);
    if (user.phone) {
      this.usersByPhone.set(user.phone, id);
    }
    
    return user;
  }

  async getUserById(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const userId = this.usersByEmail.get(email.toLowerCase());
    return userId ? this.users.get(userId) : undefined;
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    const userId = this.usersByPhone.get(phone);
    return userId ? this.users.get(userId) : undefined;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updated = { ...user, ...updates, updatedAt: new Date() };
    this.users.set(id, updated);
    
    if (updates.email && updates.email !== user.email) {
      this.usersByEmail.delete(user.email.toLowerCase());
      this.usersByEmail.set(updates.email.toLowerCase(), id);
    }
    
    if (updates.phone && updates.phone !== user.phone) {
      if (user.phone) this.usersByPhone.delete(user.phone);
      this.usersByPhone.set(updates.phone, id);
    }
    
    return updated;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async deleteUser(id: string): Promise<boolean> {
    const user = this.users.get(id);
    if (!user) return false;
    
    this.users.delete(id);
    this.usersByEmail.delete(user.email.toLowerCase());
    if (user.phone) this.usersByPhone.delete(user.phone);
    
    return true;
  }

  // Session methods
  async createSession(sessionData: InsertSession): Promise<Session> {
    const id = randomUUID();
    const session: Session = {
      ...sessionData,
      id,
      createdAt: new Date(),
    };
    
    this.sessions.set(id, session);
    this.sessionsByRefreshToken.set(session.refreshToken, id);
    
    return session;
  }

  async getSessionByRefreshToken(refreshToken: string): Promise<Session | undefined> {
    const sessionId = this.sessionsByRefreshToken.get(refreshToken);
    return sessionId ? this.sessions.get(sessionId) : undefined;
  }

  async deleteSession(id: string): Promise<boolean> {
    const session = this.sessions.get(id);
    if (!session) return false;
    
    this.sessions.delete(id);
    this.sessionsByRefreshToken.delete(session.refreshToken);
    
    return true;
  }

  async deleteUserSessions(userId: string): Promise<boolean> {
    const sessionsToDelete: string[] = [];
    
    for (const [id, session] of this.sessions.entries()) {
      if (session.userId === userId) {
        sessionsToDelete.push(id);
      }
    }
    
    sessionsToDelete.forEach(id => {
      const session = this.sessions.get(id);
      if (session) {
        this.sessions.delete(id);
        this.sessionsByRefreshToken.delete(session.refreshToken);
      }
    });
    
    return sessionsToDelete.length > 0;
  }

  // OAuth methods
  async createOAuthProvider(providerData: InsertOAuthProvider): Promise<OAuthProvider> {
    const id = randomUUID();
    const provider: OAuthProvider = {
      ...providerData,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    
    const key = `${provider.provider}:${provider.providerId}`;
    this.oauthProviders.set(key, provider);
    
    return provider;
  }

  async getOAuthProvider(provider: string, providerId: string): Promise<OAuthProvider | undefined> {
    const key = `${provider}:${providerId}`;
    return this.oauthProviders.get(key);
  }

  async getUserOAuthProviders(userId: string): Promise<OAuthProvider[]> {
    return Array.from(this.oauthProviders.values()).filter(p => p.userId === userId);
  }

  // Login attempts
  async recordLoginAttempt(email: string, ipAddress: string, success: boolean): Promise<void> {
    const id = randomUUID();
    const attempt: LoginAttempt = {
      id,
      email,
      ipAddress,
      success,
      createdAt: new Date(),
    };
    
    this.loginAttempts.set(id, attempt);
  }

  // Product methods
  async updateProduct(id: string, updates: Partial<InsertProduct>): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;
    
    const updated = { ...product, ...updates, updatedAt: new Date() };
    this.products.set(id, updated);
    
    return updated;
  }

  async deleteProduct(id: string): Promise<boolean> {
    return this.products.delete(id);
  }

  // Order methods
  async getOrdersByUserId(userId: string): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(o => o.userId === userId);
  }

  // Favorites
  async addFavorite(favoriteData: InsertFavorite): Promise<Favorite> {
    const id = randomUUID();
    const favorite: Favorite = {
      ...favoriteData,
      id,
      createdAt: new Date(),
    };
    
    const key = `${favorite.userId}:${favorite.productId}`;
    this.favorites.set(key, favorite);
    
    return favorite;
  }

  async removeFavorite(userId: string, productId: string): Promise<boolean> {
    const key = `${userId}:${productId}`;
    return this.favorites.delete(key);
  }

  async getUserFavorites(userId: string): Promise<Favorite[]> {
    return Array.from(this.favorites.values()).filter(f => f.userId === userId);
  }

  async isFavorite(userId: string, productId: string): Promise<boolean> {
    const key = `${userId}:${productId}`;
    return this.favorites.has(key);
  }

  // Notifications
  async createNotification(notificationData: InsertNotification): Promise<Notification> {
    const id = randomUUID();
    const notification: Notification = {
      ...notificationData,
      id,
      isRead: false,
      createdAt: new Date(),
    };
    
    this.notifications.set(id, notification);
    
    return notification;
  }

  async getUserNotifications(userId: string, unreadOnly = false): Promise<Notification[]> {
    let notifications = Array.from(this.notifications.values()).filter(n => n.userId === userId);
    
    if (unreadOnly) {
      notifications = notifications.filter(n => !n.isRead);
    }
    
    return notifications.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async markNotificationAsRead(id: string): Promise<boolean> {
    const notification = this.notifications.get(id);
    if (!notification) return false;
    
    notification.isRead = true;
    this.notifications.set(id, notification);
    
    return true;
  }

  async markAllNotificationsAsRead(userId: string): Promise<boolean> {
    let updated = false;
    
    for (const [id, notification] of this.notifications.entries()) {
      if (notification.userId === userId && !notification.isRead) {
        notification.isRead = true;
        this.notifications.set(id, notification);
        updated = true;
      }
    }
    
    return updated;
  }

  async deleteNotification(id: string): Promise<boolean> {
    return this.notifications.delete(id);
  }

  // Content pages
  async createContentPage(pageData: InsertContentPage): Promise<ContentPage> {
    const id = randomUUID();
    const page: ContentPage = {
      ...pageData,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    
    this.contentPages.set(id, page);
    this.contentPagesBySlug.set(page.slug, id);
    
    return page;
  }

  async getContentPage(id: string): Promise<ContentPage | undefined> {
    return this.contentPages.get(id);
  }

  async getContentPageBySlug(slug: string): Promise<ContentPage | undefined> {
    const pageId = this.contentPagesBySlug.get(slug);
    return pageId ? this.contentPages.get(pageId) : undefined;
  }

  async getAllContentPages(): Promise<ContentPage[]> {
    return Array.from(this.contentPages.values());
  }

  async updateContentPage(id: string, updates: Partial<InsertContentPage>): Promise<ContentPage | undefined> {
    const page = this.contentPages.get(id);
    if (!page) return undefined;
    
    const updated = { ...page, ...updates, updatedAt: new Date() };
    this.contentPages.set(id, updated);
    
    if (updates.slug && updates.slug !== page.slug) {
      this.contentPagesBySlug.delete(page.slug);
      this.contentPagesBySlug.set(updates.slug, id);
    }
    
    return updated;
  }

  async deleteContentPage(id: string): Promise<boolean> {
    const page = this.contentPages.get(id);
    if (!page) return false;
    
    this.contentPages.delete(id);
    this.contentPagesBySlug.delete(page.slug);
    
    return true;
  }
}

export const storage = new MemStorage();
