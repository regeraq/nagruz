#!/bin/bash
# Bash скрипт для создания архива проекта (Linux/Mac)
# Использование: chmod +x create-archive.sh && ./create-archive.sh

set -e

# Цвета для вывода
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Получаем путь к папке проекта
PROJECT_PATH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ARCHIVE_NAME="project-archive.zip"
ARCHIVE_PATH="$(dirname "$PROJECT_PATH")/$ARCHIVE_NAME"

echo -e "${GREEN}Создание архива проекта...${NC}"
echo -e "${CYAN}Путь проекта: $PROJECT_PATH${NC}"
echo -e "${CYAN}Имя архива: $ARCHIVE_NAME${NC}"

# Удаляем старый архив если существует
if [ -f "$ARCHIVE_PATH" ]; then
    echo -e "${YELLOW}Удаление старого архива...${NC}"
    rm -f "$ARCHIVE_PATH"
fi

# Создаем временную папку
TEMP_PATH=$(mktemp -d)
trap "rm -rf $TEMP_PATH" EXIT

echo -e "${CYAN}Копирование файлов...${NC}"

# Копируем файлы, исключая ненужные
rsync -av --progress \
    --exclude='node_modules' \
    --exclude='dist' \
    --exclude='build' \
    --exclude='*.log' \
    --exclude='*.tmp' \
    --exclude='.DS_Store' \
    --exclude='Thumbs.db' \
    --exclude='desktop.ini' \
    --exclude='.git' \
    --exclude='.vscode' \
    --exclude='.idea' \
    --exclude='*.zip' \
    --exclude='*.rar' \
    --exclude='*.7z' \
    --exclude='*.tar.gz' \
    --exclude='attached_assets' \
    --exclude='.cache' \
    --exclude='.temp' \
    --exclude='coverage' \
    --exclude='.nyc_output' \
    --exclude='*.db' \
    --exclude='*.sqlite' \
    --exclude='*.sqlite3' \
    --exclude='.env' \
    --exclude='.env.local' \
    --exclude='*.tsbuildinfo' \
    --exclude='vite.config.ts.*' \
    "$PROJECT_PATH/" "$TEMP_PATH/"

# Создаем ZIP архив
echo -e "${CYAN}Создание ZIP архива...${NC}"
cd "$TEMP_PATH"
zip -r "$ARCHIVE_PATH" . -q

# Получаем размер архива
ARCHIVE_SIZE=$(du -h "$ARCHIVE_PATH" | cut -f1)

echo -e "${GREEN}Архив создан успешно!${NC}"
echo -e "${CYAN}Размер архива: $ARCHIVE_SIZE${NC}"
echo -e "${CYAN}Путь: $ARCHIVE_PATH${NC}"
echo -e "\n${GREEN}Готово! Архив готов к использованию.${NC}"

