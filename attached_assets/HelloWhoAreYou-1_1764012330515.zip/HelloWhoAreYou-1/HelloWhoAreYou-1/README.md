# 🚀 Нагрузочное Устройство - Веб-сайт

Современный веб-сайт для продажи нагрузочных устройств НУ-100 и НУ-30 с улучшенной безопасностью и производительностью.

## ✨ Особенности

- 🎨 Современный UI/UX дизайн
- 🔒 Защита от DDoS атак (Rate Limiting)
- ⚡ Кэширование для высокой производительности
- 🛡️ Защита от XSS атак
- 💳 Поддержка различных способов оплаты (карты, СБП, криптовалюта)
- 📱 Адаптивный дизайн
- 🌙 Темная/светлая тема

## 🚀 Быстрый старт

### Требования

- Node.js 18+ 
- npm или yarn

### Установка

```bash
npm install
```

### Запуск

**Простой способ (Windows):**
```bash
# Дважды кликните на файл:
scripts\start-server.bat
```

Или через PowerShell:
```bash
.\scripts\start-server.ps1
```

**Или через командную строку:**
```bash
npm run dev
```

Сервер будет доступен на http://localhost:5000

### Сборка для production

```bash
npm run build
npm start
```

## 📁 Структура проекта

```
HelloWhoAreYou-1/
├── client/              # React клиентское приложение
│   ├── src/
│   │   ├── components/  # React компоненты
│   │   ├── pages/       # Страницы приложения
│   │   └── lib/         # Утилиты
├── server/              # Express сервер
│   ├── routes.ts        # API маршруты
│   ├── security.ts      # Утилиты безопасности
│   ├── rateLimiter.ts   # Rate limiting
│   └── cache.ts         # Кэширование
├── shared/              # Общий код (схемы, типы)
├── docs/                # Документация
└── scripts/             # Скрипты запуска
```

## 🔒 Безопасность

Проект включает следующие меры безопасности:

- ✅ Rate Limiting на всех API эндпоинтах
- ✅ Защита от XSS (экранирование HTML)
- ✅ Валидация и санитизация входных данных
- ✅ Security headers (X-Frame-Options, CSP и др.)
- ✅ Защита от утечки информации в ошибках

Подробнее: [docs/README_SECURITY.md](docs/README_SECURITY.md)

## 📚 Документация

Вся документация находится в папке `docs/`:

- [📖 Индекс документации](docs/README.md)
- [📋 Полный отчет по анализу кода](docs/CODE_REVIEW_REPORT.md)
- [🔒 Руководство по безопасности](docs/README_SECURITY.md)
- [🚀 Инструкция по запуску](docs/START_SERVER.md)
- [📊 Краткое резюме улучшений](docs/SUMMARY.md)
- [📁 Структура проекта](PROJECT_STRUCTURE.md)

## 🛠️ Разработка

### Скрипты

```bash
npm run dev      # Запуск в режиме разработки
npm run build    # Сборка для production
npm run start    # Запуск production версии
npm run check    # Проверка TypeScript
```

### Переменные окружения

Создайте файл `.env`:

```env
NODE_ENV=development
PORT=5000
RESEND_API_KEY=your_key_here
OWNER_EMAIL=owner@example.com
DATABASE_URL=your_database_url
```

## 📊 Улучшения производительности

- **Кэширование курсов криптовалют**: 30 секунд
- **Кэширование товаров**: 5 минут
- **Таймауты для внешних API**: 10 секунд
- **Асинхронная отправка email**: не блокирует ответ

## 🎯 API Endpoints

- `GET /api/products` - Список товаров
- `GET /api/products/:id` - Детали товара
- `GET /api/crypto-rates` - Курсы криптовалют
- `POST /api/contact` - Отправка формы обратной связи
- `POST /api/orders` - Создание заказа
- `POST /api/promo/validate` - Валидация промокода

## 📦 Создание архива для нейросети

Если вам нужно создать архив проекта для работы с нейросетью:

### Быстрый способ

**Windows:**
- Двойной клик на `create-archive.bat`
- Или запустите: `.\create-archive.ps1`

**Linux/Mac:**
```bash
chmod +x create-archive.sh
./create-archive.sh
```

Архив будет создан в родительской папке как `project-archive.zip`

### Что исключается из архива

- `node_modules/` (слишком большой)
- `dist/`, `build/` (генерируемые файлы)
- `attached_assets/` (большие медиа файлы)
- Логи, временные файлы, системные файлы

Подробная инструкция: [ARCHIVE_INSTRUCTIONS.md](ARCHIVE_INSTRUCTIONS.md)

## 📝 Лицензия

MIT

## 👥 Авторы

Разработано с использованием современных технологий и лучших практик безопасности.

