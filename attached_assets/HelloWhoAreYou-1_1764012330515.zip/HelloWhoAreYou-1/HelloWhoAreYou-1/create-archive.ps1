# PowerShell скрипт для создания архива проекта
# Использование: .\create-archive.ps1

$ErrorActionPreference = "Stop"

# Получаем путь к папке проекта
$projectPath = $PSScriptRoot
$archiveName = "project-archive.zip"
$archivePath = Join-Path (Split-Path $projectPath) $archiveName

Write-Host "Создание архива проекта..." -ForegroundColor Green
Write-Host "Путь проекта: $projectPath" -ForegroundColor Cyan
Write-Host "Имя архива: $archiveName" -ForegroundColor Cyan

# Удаляем старый архив если существует
if (Test-Path $archivePath) {
    Write-Host "Удаление старого архива..." -ForegroundColor Yellow
    Remove-Item $archivePath -Force
}

# Список исключений
$excludePatterns = @(
    "node_modules",
    "dist",
    "build",
    "*.log",
    "*.tmp",
    ".DS_Store",
    "Thumbs.db",
    "desktop.ini",
    ".git",
    ".vscode",
    ".idea",
    "*.zip",
    "*.rar",
    "*.7z",
    "*.tar.gz",
    "attached_assets",
    ".cache",
    ".temp",
    "coverage",
    ".nyc_output",
    "*.db",
    "*.sqlite",
    "*.sqlite3",
    ".env",
    ".env.local",
    "*.tsbuildinfo",
    "vite.config.ts.*"
)

# Получаем все файлы и папки
$items = Get-ChildItem -Path $projectPath -Recurse -Force | Where-Object {
    $item = $_
    $shouldExclude = $false
    
    foreach ($pattern in $excludePatterns) {
        if ($pattern -like "*.*") {
            # Паттерн для файлов
            if ($item.Name -like $pattern) {
                $shouldExclude = $true
                break
            }
        } else {
            # Паттерн для папок
            if ($item.Name -eq $pattern -or $item.FullName -like "*\$pattern\*") {
                $shouldExclude = $true
                break
            }
        }
    }
    
    return -not $shouldExclude
}

Write-Host "Найдено файлов для архивации: $($items.Count)" -ForegroundColor Cyan

# Создаем временную папку
$tempPath = Join-Path $env:TEMP "project-archive-temp"
if (Test-Path $tempPath) {
    Remove-Item $tempPath -Recurse -Force
}
New-Item -ItemType Directory -Path $tempPath | Out-Null

try {
    # Копируем файлы во временную папку, сохраняя структуру
    $copied = 0
    foreach ($item in $items) {
        $relativePath = $item.FullName.Substring($projectPath.Length + 1)
        $destPath = Join-Path $tempPath $relativePath
        $destDir = Split-Path $destPath -Parent
        
        if (-not (Test-Path $destDir)) {
            New-Item -ItemType Directory -Path $destDir -Force | Out-Null
        }
        
        Copy-Item -Path $item.FullName -Destination $destPath -Force
        $copied++
        
        if ($copied % 100 -eq 0) {
            Write-Progress -Activity "Копирование файлов" -Status "$copied из $($items.Count)" -PercentComplete (($copied / $items.Count) * 100)
        }
    }
    
    Write-Progress -Activity "Копирование файлов" -Completed
    
    # Создаем ZIP архив
    Write-Host "Создание ZIP архива..." -ForegroundColor Cyan
    Compress-Archive -Path "$tempPath\*" -DestinationPath $archivePath -CompressionLevel Optimal -Force
    
    # Получаем размер архива
    $archiveSize = (Get-Item $archivePath).Length / 1MB
    Write-Host "Архив создан успешно!" -ForegroundColor Green
    Write-Host "Размер архива: $([math]::Round($archiveSize, 2)) МБ" -ForegroundColor Cyan
    Write-Host "Путь: $archivePath" -ForegroundColor Cyan
    
} finally {
    # Удаляем временную папку
    if (Test-Path $tempPath) {
        Remove-Item $tempPath -Recurse -Force
    }
}

Write-Host "`nГотово! Архив готов к использованию." -ForegroundColor Green

