import { generateNumericId } from "./utils";

export interface IStorage {
  getUserByEmail(email: string): Promise<any>;
  getUserById(id: string): Promise<any>;
  createUser(user: any): Promise<any>;
  getSessionByToken(token: string): Promise<any>;
  createSession(session: any): Promise<any>;
  deleteSession(id: string): Promise<boolean>;
  getAllNotifications(userId: string): Promise<any[]>;
  markNotificationAsRead(id: string): Promise<void>;
  deleteNotification(id: string): Promise<boolean>;
  clearUserNotifications(userId: string): Promise<boolean>;
  createNotification(notification: any): Promise<any>;
  getProducts(): Promise<any[]>;
  getProduct(id: string): Promise<any>;
  getContact(id: string): Promise<any>;
  createContactSubmission(data: any): Promise<any>;
  getContactSubmissions(): Promise<any[]>;
  getContactSubmission(id: string): Promise<any>;
  recordLoginAttempt(email: string, success: boolean): Promise<void>;
  getOrder(id: string): Promise<any>;
  updateOrderStatus(id: string, status: string, details?: string): Promise<any>;
  createOrder(order: any): Promise<any>;
  getUserOrders(userId: string): Promise<any[]>;
  getAllOrders(): Promise<any[]>;
  addToFavorites(userId: string, productId: string): Promise<any>;
  removeFavorite(userId: string, productId: string): Promise<boolean>;
  getUserFavorites(userId: string): Promise<any[]>;
  validatePromoCode(code: string): Promise<any>;
}

export class MemStorage implements IStorage {
  public users = new Map();
  private sessions = new Map();
  private notifications = new Map();
  private contacts = new Map();
  private orders = new Map();
  private favorites = new Map();
  private loginAttempts = new Map();
  private promoCodes = new Map();
  private siteSettings = new Map();
  private products = [
    {
      id: "nu-100",
      name: "НУ-100",
      description: "Professional load device",
      price: "100000",
      currency: "RUB",
      sku: "NU-100",
      specifications: "100 кВт, 20 ступеней",
      stock: 10,
      category: "Industrial",
      imageUrl: null,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: "nu-30",
      name: "НУ-30",
      description: "Compact load device",
      price: "50000",
      currency: "RUB",
      sku: "NU-30",
      specifications: "30 кВт, 6 ступеней",
      stock: 15,
      category: "Industrial",
      imageUrl: null,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ];

  async getUserByEmail(email: string) {
    return Array.from(this.users.values()).find((u: any) => u.email === email);
  }

  async getUserById(id: string) {
    return this.users.get(id);
  }

  async createUser(user: any) {
    const id = generateNumericId();
    const newUser = {
      id,
      email: user.email,
      password: user.password || null,
      passwordHash: user.passwordHash || user.password || null,
      firstName: user.firstName || null,
      lastName: user.lastName || null,
      avatar: user.avatar || null,
      phone: user.phone || null,
      role: user.role || "user",
      isEmailVerified: user.isEmailVerified || false,
      isPhoneVerified: user.isPhoneVerified || false,
      isBlocked: user.isBlocked || false,
      createdAt: new Date(),
    };
    this.users.set(id, newUser);
    return newUser;
  }

  async getSessionByToken(token: string) {
    return Array.from(this.sessions.values()).find((s: any) => s.token === token);
  }

  async createSession(session: any) {
    const id = generateNumericId();
    const newSession = { id, ...session };
    this.sessions.set(id, newSession);
    return newSession;
  }

  async deleteSession(id: string) {
    return this.sessions.delete(id);
  }

  async getAllNotifications(userId: string) {
    return Array.from(this.notifications.values()).filter((n: any) => n.userId === userId);
  }

  async markNotificationAsRead(id: string) {
    const notif = this.notifications.get(id);
    if (notif) notif.isRead = true;
  }

  async deleteNotification(id: string) {
    return this.notifications.delete(id);
  }

  async clearUserNotifications(userId: string) {
    const notificationsToDelete = Array.from(this.notifications.values()).filter((n: any) => n.userId === userId);
    notificationsToDelete.forEach((n: any) => {
      Array.from(this.notifications.entries()).forEach(([key, val]) => {
        if (val === n) this.notifications.delete(key);
      });
    });
    return true;
  }

  async createNotification(notification: any) {
    const id = generateNumericId();
    const newNotification = { id, ...notification, createdAt: new Date() };
    this.notifications.set(id, newNotification);
    return newNotification;
  }

  async getProducts() {
    return this.products;
  }

  async getProduct(id: string) {
    return this.products.find((p: any) => p.id === id);
  }

  async getContact(id: string) {
    return this.contacts.get(id);
  }

  async createContactSubmission(data: any) {
    const id = generateNumericId();
    const submission = { id, ...data, createdAt: new Date() };
    this.contacts.set(id, submission);
    return submission;
  }

  async getContactSubmissions() {
    return Array.from(this.contacts.values());
  }

  async getContactSubmission(id: string) {
    return this.contacts.get(id);
  }

  async recordLoginAttempt(email: string, success: boolean) {
    if (!this.loginAttempts.has(email)) {
      this.loginAttempts.set(email, []);
    }
    const attempts = this.loginAttempts.get(email);
    attempts.push({ timestamp: new Date(), success });
    if (attempts.length > 100) attempts.shift();
  }

  async getOrder(id: string) {
    return this.orders.get(id);
  }

  async updateOrderStatus(id: string, status: string, details?: string) {
    const order = this.orders.get(id);
    if (order) {
      order.paymentStatus = status;
      order.paymentDetails = details;
      order.updatedAt = new Date();
    }
    return order;
  }

  async createOrder(order: any) {
    const product = this.products.find(p => p.id === order.productId);
    const id = generateNumericId();
    const quantity = order.quantity || 1;
    const price = product ? parseFloat(product.price) : 0;
    // Используем переданные значения или вычисляем
    const totalAmount = order.totalAmount || (price * quantity).toString();
    const finalAmount = order.finalAmount || totalAmount;
    const discountAmount = order.discountAmount || "0";
    
    const newOrder = { 
      id, 
      ...order, 
      quantity,
      totalAmount,
      discountAmount,
      finalAmount,
      productName: product?.name || "",
      productPrice: product?.price || "0",
      paymentStatus: order.paymentStatus || "pending",
      createdAt: new Date(), 
      updatedAt: new Date() 
    };
    this.orders.set(id, newOrder);
    if (product && product.stock >= quantity) {
      product.stock -= quantity;
    }
    return newOrder;
  }

  async getUserOrders(userId: string) {
    return Array.from(this.orders.values()).filter((o: any) => o.userId === userId);
  }

  async getAllOrders() {
    return Array.from(this.orders.values());
  }

  async addToFavorites(userId: string, productId: string) {
    const key = `${userId}:${productId}`;
    const product = this.products.find((p: any) => p.id === productId);
    if (!product) return null;
    const favorite = { userId, productId, product, createdAt: new Date() };
    this.favorites.set(key, favorite);
    return favorite;
  }

  async removeFavorite(userId: string, productId: string) {
    const key = `${userId}:${productId}`;
    return this.favorites.delete(key);
  }

  async getUserFavorites(userId: string) {
    return Array.from(this.favorites.values()).filter((f: any) => f.userId === userId);
  }

  async validatePromoCode(code: string) {
    if (!this.promoCodes) {
      return { valid: false, discount: 0 };
    }
    const promo = Array.from(this.promoCodes.values()).find(
      (p: any) => p.code === code && p.isActive && (!p.expiresAt || new Date(p.expiresAt) > new Date())
    );
    if (promo) {
      return { valid: true, discount: promo.discountPercent, code: promo.code, discountPercent: promo.discountPercent };
    }
    return { valid: false, discount: 0 };
  }

  async updateProductPrice(id: string, price: string) {
    const product = this.products.find(p => p.id === id);
    if (product) {
      product.price = price;
      product.updatedAt = new Date();
    }
    return product;
  }

  async updateProductInfo(id: string, data: any) {
    const product = this.products.find(p => p.id === id);
    if (product) {
      Object.assign(product, data, { updatedAt: new Date() });
    }
    return product;
  }

  async createProduct(data: any) {
    const id = data.id || generateNumericId();
    const newProduct = {
      id,
      name: data.name,
      description: data.description || "",
      price: data.price,
      currency: data.currency || "RUB",
      sku: data.sku,
      specifications: data.specifications || "",
      stock: data.stock || 0,
      category: data.category || null,
      imageUrl: data.imageUrl || null,
      isActive: data.isActive !== undefined ? data.isActive : true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.products.push(newProduct);
    return newProduct;
  }

  async deleteProduct(id: string) {
    const index = this.products.findIndex(p => p.id === id);
    if (index !== -1) {
      this.products.splice(index, 1);
      return true;
    }
    return false;
  }

  async deleteProducts(ids: string[]) {
    ids.forEach(id => {
      const index = this.products.findIndex(p => p.id === id);
      if (index !== -1) {
        this.products.splice(index, 1);
      }
    });
    return ids.length;
  }

  async updateUserRole(userId: string, role: string) {
    const user = this.users.get(userId);
    if (user) {
      user.role = role;
      user.updatedAt = new Date();
    }
    return user;
  }

  async blockUser(userId: string, isBlocked: boolean) {
    const user = this.users.get(userId);
    if (user) {
      user.isBlocked = isBlocked;
      user.updatedAt = new Date();
    }
    return user;
  }

  async deleteUser(userId: string) {
    return this.users.delete(userId);
  }

  async createPromoCode(data: any) {
    const id = generateNumericId();
    const promoCode = {
      id,
      code: data.code,
      discountPercent: data.discountPercent,
      expiresAt: data.expiresAt ? new Date(data.expiresAt) : null,
      isActive: data.isActive !== undefined ? data.isActive : true,
      createdAt: new Date(),
    };
    if (!this.promoCodes) {
      this.promoCodes = new Map();
    }
    this.promoCodes.set(id, promoCode);
    return promoCode;
  }

  async getPromoCodes() {
    if (!this.promoCodes) {
      return [];
    }
    return Array.from(this.promoCodes.values());
  }

  async getPromoCode(id: string) {
    if (!this.promoCodes) {
      return null;
    }
    return this.promoCodes.get(id);
  }

  async updatePromoCode(id: string, data: any) {
    if (!this.promoCodes) {
      return null;
    }
    const promoCode = this.promoCodes.get(id);
    if (promoCode) {
      Object.assign(promoCode, data);
    }
    return promoCode;
  }

  async deletePromoCode(id: string) {
    if (!this.promoCodes) {
      return false;
    }
    return this.promoCodes.delete(id);
  }

  async getSiteSettings() {
    if (!this.siteSettings) {
      this.siteSettings = new Map();
    }
    return Array.from(this.siteSettings.values());
  }

  async getSiteSetting(key: string) {
    if (!this.siteSettings) {
      return null;
    }
    return Array.from(this.siteSettings.values()).find((s: any) => s.key === key);
  }

  async setSiteSetting(key: string, value: string, type: string = "string", description?: string) {
    if (!this.siteSettings) {
      this.siteSettings = new Map();
    }
    const existing = Array.from(this.siteSettings.values()).find((s: any) => s.key === key);
    if (existing) {
      existing.value = value;
      existing.type = type;
      if (description) existing.description = description;
      existing.updatedAt = new Date();
      return existing;
    } else {
      const id = generateNumericId();
      const setting = {
        id,
        key,
        value,
        type,
        description: description || null,
        updatedAt: new Date(),
      };
      this.siteSettings.set(id, setting);
      return setting;
    }
  }

  async deleteContactSubmission(id: string) {
    return this.contacts.delete(id);
  }

  async updateContactSubmissionStatus(id: string, status: string) {
    const submission = this.contacts.get(id);
    if (submission) {
      submission.status = status;
      submission.updatedAt = new Date();
    }
    return submission;
  }
}

export const storage = new MemStorage();
