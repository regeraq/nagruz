import { useLocation } from "wouter";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Package, Users, BarChart3, FileText, Settings, Plus, Edit2, Trash2, Save, X, CheckCircle2, Search, Shield, Tag, Mail, Ban, Unlock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ru } from "date-fns/locale/ru";

interface Product {
  id: string;
  name: string;
  description?: string;
  price: string;
  stock: number;
  sku: string;
  specifications?: string;
  category?: string;
  imageUrl?: string;
  isActive: boolean;
}

interface User {
  id: string;
  email: string;
  firstName?: string;
  lastName?: string;
  role: string;
  isBlocked?: boolean;
  createdAt: string;
}

interface Order {
  id: string;
  userId: string;
  productId: string;
  quantity: number;
  totalAmount: string;
  finalAmount: string;
  paymentStatus: string;
  paymentMethod: string;
  createdAt: string;
}

interface ContactSubmission {
  id: string;
  name: string;
  email: string;
  phone: string;
  company: string;
  message: string;
  fileName?: string;
  createdAt: string;
}

interface PromoCode {
  id: string;
  code: string;
  discountPercent: number;
  expiresAt?: string;
  isActive: boolean;
  createdAt: string;
}

export default function Admin() {
  const [, setLocation] = useLocation();
  const [selectedProducts, setSelectedProducts] = useState<Set<string>>(new Set());
  const [editingProduct, setEditingProduct] = useState<string | null>(null);
  const [editingStock, setEditingStock] = useState<number | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [searchUserId, setSearchUserId] = useState("");
  const [selectedUserDetail, setSelectedUserDetail] = useState<any>(null);
  const [selectedOrderDetail, setSelectedOrderDetail] = useState<any>(null);
  const [orderStatusDialog, setOrderStatusDialog] = useState(false);
  const [newOrderStatus, setNewOrderStatus] = useState("");
  const [editingProductPrice, setEditingProductPrice] = useState<string | null>(null);
  const [newProductPrice, setNewProductPrice] = useState("");
  const [showPriceDialog, setShowPriceDialog] = useState(false);
  const [selectedEditProduct, setSelectedEditProduct] = useState<any>(null);
  const [showAddProductDialog, setShowAddProductDialog] = useState(false);
  const [showEditProductDialog, setShowEditProductDialog] = useState(false);
  const [showCreateAdminDialog, setShowCreateAdminDialog] = useState(false);
  const [showUserRoleDialog, setShowUserRoleDialog] = useState(false);
  const [selectedUserForRole, setSelectedUserForRole] = useState<any>(null);
  const [newUserRole, setNewUserRole] = useState("");
  const [newProduct, setNewProduct] = useState({ name: "", price: "", sku: "", stock: 0, description: "", specifications: "", category: "", isActive: true });
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [newAdmin, setNewAdmin] = useState({ email: "", password: "", firstName: "", lastName: "", role: "admin" });
  const [showCreatePromoDialog, setShowCreatePromoDialog] = useState(false);
  const [newPromoCode, setNewPromoCode] = useState({ code: "", discountPercent: 0, expiresAt: "", isActive: true });
  const [activeTab, setActiveTab] = useState("products");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: userData } = useQuery({
    queryKey: ["/api/auth/me"],
    queryFn: async () => {
      const token = localStorage.getItem("accessToken");
      if (!token) throw new Error("Not authenticated");

      const res = await fetch("/api/auth/me", {
        headers: { Authorization: `Bearer ${token}` },
        credentials: "include",
      });

      if (!res.ok) throw new Error("Failed to fetch user");
      const data = await res.json();
      return data.user;
    },
  });

  const { data: products = [], isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: ["/api/products"],
    queryFn: async () => {
      const token = localStorage.getItem("accessToken");
      if (!token) return [];

      const res = await fetch("/api/products", {
        headers: { Authorization: `Bearer ${token}` },
        credentials: "include",
      });

      if (!res.ok) return [];
      return res.json();
    },
  });

  const { data: users = [], isLoading: isLoadingUsers } = useQuery({
    queryKey: ["/api/admin/users"],
    queryFn: async () => {
      const token = localStorage.getItem("accessToken");
      if (!token) return [];

      const res = await fetch("/api/admin/users", {
        headers: { Authorization: `Bearer ${token}` },
        credentials: "include",
      });

      if (!res.ok) return [];
      return res.json();
    },
  });

  const { data: orders = [], isLoading: isLoadingOrders } = useQuery<Order[]>({
    queryKey: ["/api/admin/orders"],
    queryFn: async () => {
      const token = localStorage.getItem("accessToken");
      if (!token) return [];

      const res = await fetch("/api/admin/orders", {
        headers: { Authorization: `Bearer ${token}` },
        credentials: "include",
      });

      if (!res.ok) return [];
      return res.json();
    },
  });

  const { data: contacts = [], isLoading: isLoadingContacts } = useQuery<ContactSubmission[]>({
    queryKey: ["/api/admin/contacts"],
    queryFn: async () => {
      const token = localStorage.getItem("accessToken");
      if (!token) return [];

      const res = await fetch("/api/admin/contacts", {
        headers: { Authorization: `Bearer ${token}` },
        credentials: "include",
      });

      if (!res.ok) return [];
      return res.json();
    },
  });

  const { data: promoCodes = [], isLoading: isLoadingPromoCodes } = useQuery<PromoCode[]>({
    queryKey: ["/api/admin/promocodes"],
    queryFn: async () => {
      const token = localStorage.getItem("accessToken");
      if (!token) return [];

      const res = await fetch("/api/admin/promocodes", {
        headers: { Authorization: `Bearer ${token}` },
        credentials: "include",
      });

      if (!res.ok) return [];
      return res.json();
    },
  });

  const { data: siteSettings = [] } = useQuery({
    queryKey: ["/api/admin/settings"],
    queryFn: async () => {
      const token = localStorage.getItem("accessToken");
      if (!token) return [];

      const res = await fetch("/api/admin/settings", {
        headers: { Authorization: `Bearer ${token}` },
        credentials: "include",
      });

      if (!res.ok) return [];
      return res.json();
    },
  });

  const updateProductStock = useMutation({
    mutationFn: async ({ id, stock }: { id: string; stock: number }) => {
      const token = localStorage.getItem("accessToken");
      if (!token) throw new Error("Not authenticated");

      const res = await fetch(`/api/admin/products/${id}/stock`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({ stock }),
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Ошибка при обновлении");
      }

      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      setEditingProduct(null);
      setEditingStock(null);
      toast({
        title: "Успешно",
        description: "Количество обновлено",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateOrderStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const token = localStorage.getItem("accessToken");
      if (!token) throw new Error("Not authenticated");

      const res = await fetch(`/api/admin/orders/${id}`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({ paymentStatus: status }),
      });

      if (!res.ok) throw new Error("Ошибка при обновлении");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/orders"] });
      setOrderStatusDialog(false);
      setNewOrderStatus("");
      toast({
        title: "Успешно",
        description: "Статус заказа обновлен",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateProductPrice = useMutation({
    mutationFn: async ({ id, price }: { id: string; price: string }) => {
      const token = localStorage.getItem("accessToken");
      if (!token) throw new Error("Not authenticated");

      const res = await fetch(`/api/admin/products/${id}/price`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({ price }),
      });

      if (!res.ok) throw new Error("Ошибка при обновлении цены");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      setShowPriceDialog(false);
      setSelectedEditProduct(null);
      setNewProductPrice("");
      toast({
        title: "Успешно",
        description: "Цена товара обновлена",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteProducts = useMutation({
    mutationFn: async (ids: string[]) => {
      const token = localStorage.getItem("accessToken");
      if (!token) throw new Error("Not authenticated");

      const res = await fetch("/api/admin/products", {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({ ids }),
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Ошибка при удалении");
      }

      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      setSelectedProducts(new Set());
      setShowDeleteDialog(false);
      toast({
        title: "Успешно",
        description: "Товары удалены",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createProduct = useMutation({
    mutationFn: async (product: any) => {
      const token = localStorage.getItem("accessToken");
      if (!token) throw new Error("Not authenticated");

      const res = await fetch("/api/admin/products", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify(product),
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Ошибка при создании");
      }

      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      setShowAddProductDialog(false);
      setNewProduct({ name: "", price: "", sku: "", stock: 0, description: "", specifications: "", category: "", isActive: true });
      toast({
        title: "Успешно",
        description: "Товар создан",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateProduct = useMutation({
    mutationFn: async ({ id, ...data }: any) => {
      const token = localStorage.getItem("accessToken");
      if (!token) throw new Error("Not authenticated");

      const res = await fetch(`/api/admin/products/${id}`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Ошибка при обновлении");
      }

      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      setShowEditProductDialog(false);
      setEditingProduct(null);
      toast({
        title: "Успешно",
        description: "Товар обновлен",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateUserRole = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: string }) => {
      const token = localStorage.getItem("accessToken");
      if (!token) throw new Error("Not authenticated");

      const res = await fetch(`/api/admin/users/${userId}/role`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({ role }),
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Ошибка при обновлении");
      }

      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setShowUserRoleDialog(false);
      setSelectedUserForRole(null);
      toast({
        title: "Успешно",
        description: "Роль пользователя обновлена",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const blockUser = useMutation({
    mutationFn: async ({ userId, isBlocked }: { userId: string; isBlocked: boolean }) => {
      const token = localStorage.getItem("accessToken");
      if (!token) throw new Error("Not authenticated");

      const res = await fetch(`/api/admin/users/${userId}/block`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({ isBlocked }),
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Ошибка при обновлении");
      }

      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Успешно",
        description: "Статус пользователя обновлен",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createAdmin = useMutation({
    mutationFn: async (admin: any) => {
      const token = localStorage.getItem("accessToken");
      if (!token) throw new Error("Not authenticated");

      const res = await fetch("/api/admin/admins", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify(admin),
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Ошибка при создании");
      }

      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setShowCreateAdminDialog(false);
      setNewAdmin({ email: "", password: "", firstName: "", lastName: "", role: "admin" });
      toast({
        title: "Успешно",
        description: `Администратор создан: ${data.user.email}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteContact = useMutation({
    mutationFn: async (id: string) => {
      const token = localStorage.getItem("accessToken");
      if (!token) throw new Error("Not authenticated");

      const res = await fetch(`/api/admin/contacts/${id}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        credentials: "include",
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Ошибка при удалении");
      }

      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/contacts"] });
      toast({
        title: "Успешно",
        description: "Заявка удалена",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createPromoCode = useMutation({
    mutationFn: async (promoCode: any) => {
      const token = localStorage.getItem("accessToken");
      if (!token) throw new Error("Not authenticated");

      const res = await fetch("/api/admin/promocodes", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify(promoCode),
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Ошибка при создании");
      }

      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/promocodes"] });
      toast({
        title: "Успешно",
        description: "Промокод создан",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deletePromoCode = useMutation({
    mutationFn: async (id: string) => {
      const token = localStorage.getItem("accessToken");
      if (!token) throw new Error("Not authenticated");

      const res = await fetch(`/api/admin/promocodes/${id}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        credentials: "include",
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Ошибка при удалении");
      }

      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/promocodes"] });
      toast({
        title: "Успешно",
        description: "Промокод удален",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleStockEdit = (product: Product) => {
    setEditingProduct(product.id);
    setEditingStock(product.stock);
  };

  const handleStockSave = (id: string) => {
    if (editingStock !== null && editingStock >= 0) {
      updateProductStock.mutate({ id, stock: editingStock });
    }
  };

  const handleStockCancel = () => {
    setEditingProduct(null);
    setEditingStock(null);
  };

  const toggleProductSelection = (id: string) => {
    const newSelected = new Set(selectedProducts);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedProducts(newSelected);
  };

  const toggleAllProducts = () => {
    if (selectedProducts.size === products.length) {
      setSelectedProducts(new Set());
    } else {
      setSelectedProducts(new Set(products.map(p => p.id)));
    }
  };

  const handleBulkDelete = () => {
    if (selectedProducts.size === 0) return;
    setShowDeleteDialog(true);
  };

  const confirmBulkDelete = () => {
    deleteProducts.mutate(Array.from(selectedProducts));
  };

  const handleSearchUser = (userId: string) => {
    if (!userId.trim()) {
      setSelectedUserDetail(null);
      return;
    }
    const found = users.find((u: any) => u.id === userId);
    if (found) {
      const userOrders = orders.filter((o: any) => o.userId === userId);
      setSelectedUserDetail({ ...found, orders: userOrders });
    } else {
      toast({
        title: "Не найдено",
        description: "Пользователь с таким ID не найден",
        variant: "destructive",
      });
      setSelectedUserDetail(null);
    }
  };

  const handleOrderStatusChange = (order: Order) => {
    setSelectedOrderDetail(order);
    setNewOrderStatus(order.paymentStatus);
    setOrderStatusDialog(true);
  };

  const confirmOrderStatusChange = () => {
    if (selectedOrderDetail && newOrderStatus) {
      updateOrderStatus.mutate({
        id: selectedOrderDetail.id,
        status: newOrderStatus,
      });
    }
  };

  const isAdmin = userData?.role === "admin" || userData?.role === "superadmin" || userData?.role === "moderator";

  if (!isAdmin) {
    return (
      <div className="container mx-auto px-4 py-8 pt-24">
        <Card>
          <CardContent className="pt-6">
            <Alert>
              <AlertDescription>У вас нет доступа к админ-панели</AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>
    );
  }

  const totalRevenue = orders.reduce((sum, o) => sum + parseFloat(o.finalAmount), 0);
  const deliveredOrders = orders.filter(o => o.paymentStatus === "delivered").length;
  const processingOrders = orders.filter(o => o.paymentStatus === "processing").length;

  return (
    <div className="container mx-auto px-4 py-8 pt-24">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-4xl font-bold">Админ-панель</h1>
          <div className="flex items-center gap-4">
            <Badge variant="outline" className="text-sm">
              {userData?.role}
            </Badge>
            <Button variant="outline" onClick={() => setLocation("/")} data-testid="button-go-home">
              На главную
            </Button>
          </div>
        </div>

        <Tabs defaultValue="products" className="w-full" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-8">
            <TabsTrigger value="products">
              <Package className="w-4 h-4 mr-2" />
              Товары
            </TabsTrigger>
            <TabsTrigger value="users">
              <Users className="w-4 h-4 mr-2" />
              Пользователи
            </TabsTrigger>
            <TabsTrigger value="orders">
              <Package className="w-4 h-4 mr-2" />
              Заказы
            </TabsTrigger>
            <TabsTrigger value="contacts">
              <Mail className="w-4 h-4 mr-2" />
              Заявки
            </TabsTrigger>
            <TabsTrigger value="promocodes">
              <Tag className="w-4 h-4 mr-2" />
              Промокоды
            </TabsTrigger>
            <TabsTrigger value="admins">
              <Shield className="w-4 h-4 mr-2" />
              Админы
            </TabsTrigger>
            <TabsTrigger value="analytics">
              <BarChart3 className="w-4 h-4 mr-2" />
              Аналитика
            </TabsTrigger>
            <TabsTrigger value="settings">
              <Settings className="w-4 h-4 mr-2" />
              Настройки
            </TabsTrigger>
          </TabsList>

          <TabsContent value="products" className="mt-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Управление товарами</CardTitle>
                    <CardDescription>CRUD операции для товаров</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    {selectedProducts.size > 0 && (
                      <Button
                        variant="destructive"
                        onClick={handleBulkDelete}
                        disabled={deleteProducts.isPending}
                        data-testid="button-delete-selected"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Удалить ({selectedProducts.size})
                      </Button>
                    )}
                    <Button 
                      data-testid="button-add-product"
                      onClick={() => setShowAddProductDialog(true)}
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Добавить товар
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {isLoadingProducts ? (
                  <div className="text-center py-12">
                    <div className="animate-pulse">Загрузка...</div>
                  </div>
                ) : products.length === 0 ? (
                  <div className="text-center py-12">
                    <Package className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">Товары не найдены</p>
                  </div>
                ) : (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-12">
                            <Checkbox
                              checked={selectedProducts.size === products.length && products.length > 0}
                              onCheckedChange={toggleAllProducts}
                              data-testid="checkbox-select-all"
                            />
                          </TableHead>
                          <TableHead>Название</TableHead>
                          <TableHead>Артикул</TableHead>
                          <TableHead>Цена</TableHead>
                          <TableHead>Количество</TableHead>
                          <TableHead>Статус</TableHead>
                          <TableHead className="text-right">Действия</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {products.map((product) => (
                          <TableRow key={product.id} data-testid={`row-product-${product.id}`}>
                            <TableCell>
                              <Checkbox
                                checked={selectedProducts.has(product.id)}
                                onCheckedChange={() => toggleProductSelection(product.id)}
                                data-testid={`checkbox-product-${product.id}`}
                              />
                            </TableCell>
                            <TableCell className="font-medium" data-testid={`cell-name-${product.id}`}>{product.name}</TableCell>
                            <TableCell data-testid={`cell-sku-${product.id}`}>{product.sku}</TableCell>
                            <TableCell data-testid={`cell-price-${product.id}`}>{product.price} ₽</TableCell>
                            <TableCell>
                              {editingProduct === product.id ? (
                                <div className="flex items-center gap-2">
                                  <Input
                                    type="number"
                                    value={editingStock ?? 0}
                                    onChange={(e) => setEditingStock(parseInt(e.target.value) || 0)}
                                    className="w-20"
                                    min="0"
                                    autoFocus
                                    data-testid={`input-stock-${product.id}`}
                                  />
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => handleStockSave(product.id)}
                                    disabled={updateProductStock.isPending}
                                    data-testid={`button-save-stock-${product.id}`}
                                  >
                                    <Save className="w-4 h-4" />
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={handleStockCancel}
                                    disabled={updateProductStock.isPending}
                                    data-testid={`button-cancel-stock-${product.id}`}
                                  >
                                    <X className="w-4 h-4" />
                                  </Button>
                                </div>
                              ) : (
                                <div className="flex items-center gap-2">
                                  <span data-testid={`text-stock-${product.id}`}>{product.stock}</span>
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => handleStockEdit(product)}
                                    data-testid={`button-edit-stock-${product.id}`}
                                  >
                                    <Edit2 className="w-4 h-4" />
                                  </Button>
                                </div>
                              )}
                            </TableCell>
                            <TableCell>
                              <Badge variant={product.isActive ? "default" : "secondary"} data-testid={`badge-status-${product.id}`}>
                                {product.isActive ? "Активен" : "Неактивен"}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <Button 
                                  size="sm" 
                                  variant="ghost" 
                                  onClick={() => {
                                    setEditingProduct(product);
                                    setShowEditProductDialog(true);
                                  }}
                                  data-testid={`button-edit-product-${product.id}`}
                                  title="Редактировать товар"
                                >
                                  <Edit2 className="w-4 h-4" />
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="ghost" 
                                  onClick={() => {
                                    setSelectedEditProduct(product);
                                    setNewProductPrice(product.price);
                                    setShowPriceDialog(true);
                                  }}
                                  data-testid={`button-edit-price-${product.id}`}
                                  title="Редактировать цену"
                                >
                                  <Edit2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users" className="mt-6">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Поиск пользователя по ID</CardTitle>
                  <CardDescription>Введите ID пользователя для просмотра деталей и заказов</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Введите ID пользователя..."
                      value={searchUserId}
                      onChange={(e) => setSearchUserId(e.target.value)}
                      data-testid="input-search-user"
                    />
                    <Button
                      onClick={() => handleSearchUser(searchUserId)}
                      data-testid="button-search-user"
                    >
                      <Search className="w-4 h-4 mr-2" />
                      Поиск
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {selectedUserDetail && (
                <Card>
                  <CardHeader>
                    <CardTitle>Профиль пользователя</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-muted-foreground text-sm">ID</p>
                        <p className="font-semibold" data-testid="text-user-id">{selectedUserDetail.id}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground text-sm">Email</p>
                        <p className="font-semibold" data-testid="text-user-email">{selectedUserDetail.email}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground text-sm">Имя</p>
                        <p className="font-semibold" data-testid="text-user-name">
                          {selectedUserDetail.firstName && selectedUserDetail.lastName
                            ? `${selectedUserDetail.firstName} ${selectedUserDetail.lastName}`
                            : "—"}
                        </p>
                      </div>
                      <div>
                        <p className="text-muted-foreground text-sm">Роль</p>
                        <Badge variant="outline" data-testid="badge-user-role">{selectedUserDetail.role}</Badge>
                      </div>
                      <div className="col-span-2">
                        <p className="text-muted-foreground text-sm">Дата регистрации</p>
                        <p className="font-semibold" data-testid="text-user-created">
                          {format(new Date(selectedUserDetail.createdAt), "d MMMM yyyy, HH:mm", { locale: ru })}
                        </p>
                      </div>
                    </div>

                    {selectedUserDetail.orders && selectedUserDetail.orders.length > 0 && (
                      <div className="mt-6">
                        <h3 className="font-semibold mb-4">Заказы пользователя ({selectedUserDetail.orders.length})</h3>
                        <div className="space-y-2">
                          {selectedUserDetail.orders.map((order: Order) => (
                            <Card key={order.id} data-testid={`card-user-order-${order.id}`}>
                              <CardContent className="pt-4">
                                <div className="flex items-center justify-between">
                                  <div>
                                    <p className="font-semibold text-sm"># {order.id.slice(0, 8)}</p>
                                    <p className="text-xs text-muted-foreground">
                                      {format(new Date(order.createdAt), "d MMM yyyy", { locale: ru })}
                                    </p>
                                  </div>
                                  <div className="text-right">
                                    <p className="font-semibold">{order.finalAmount} ₽</p>
                                    <Badge
                                      variant={order.paymentStatus === "delivered" ? "default" : "secondary"}
                                      className="text-xs"
                                      data-testid={`badge-order-status-${order.id}`}
                                    >
                                      {order.paymentStatus}
                                    </Badge>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              <Card>
                <CardHeader>
                  <CardTitle>Все пользователи</CardTitle>
                  <CardDescription>Список всех зарегистрированных пользователей</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoadingUsers ? (
                    <div className="text-center py-12">
                      <div className="animate-pulse">Загрузка...</div>
                    </div>
                  ) : users.length === 0 ? (
                    <div className="text-center py-12">
                      <Users className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                      <p className="text-muted-foreground">Пользователи не найдены</p>
                    </div>
                  ) : (
                    <div className="rounded-md border">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Email</TableHead>
                            <TableHead>Имя</TableHead>
                            <TableHead>Роль</TableHead>
                            <TableHead>Дата регистрации</TableHead>
                            <TableHead className="text-right">Действия</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {users.map((user: any) => (
                            <TableRow key={user.id} data-testid={`row-user-${user.id}`}>
                              <TableCell className="font-medium" data-testid={`cell-email-${user.id}`}>{user.email}</TableCell>
                              <TableCell data-testid={`cell-name-${user.id}`}>
                                {user.firstName && user.lastName
                                  ? `${user.firstName} ${user.lastName}`
                                  : "—"}
                              </TableCell>
                              <TableCell>
                                <Badge variant="outline" data-testid={`badge-role-${user.id}`}>{user.role}</Badge>
                              </TableCell>
                              <TableCell data-testid={`cell-created-${user.id}`}>
                                {format(new Date(user.createdAt), "d MMM yyyy", { locale: ru })}
                              </TableCell>
                              <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => {
                                      setSearchUserId(user.id);
                                      handleSearchUser(user.id);
                                    }}
                                    data-testid={`button-view-user-${user.id}`}
                                    title="Просмотр"
                                  >
                                    <Edit2 className="w-4 h-4" />
                                  </Button>
                                  {userData?.role === "superadmin" && (
                                    <>
                                      <Button
                                        size="sm"
                                        variant="ghost"
                                        onClick={() => {
                                          setSelectedUserForRole(user);
                                          setNewUserRole(user.role);
                                          setShowUserRoleDialog(true);
                                        }}
                                        title="Изменить роль"
                                      >
                                        <Shield className="w-4 h-4" />
                                      </Button>
                                      <Button
                                        size="sm"
                                        variant="ghost"
                                        onClick={() => {
                                          blockUser.mutate({ userId: user.id, isBlocked: !user.isBlocked });
                                        }}
                                        title={user.isBlocked ? "Разблокировать" : "Заблокировать"}
                                      >
                                        {user.isBlocked ? <Unlock className="w-4 h-4" /> : <Ban className="w-4 h-4" />}
                                      </Button>
                                    </>
                                  )}
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="orders" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Управление заказами</CardTitle>
                <CardDescription>Просмотр и управление всеми заказами</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingOrders ? (
                  <div className="text-center py-12">
                    <div className="animate-pulse">Загрузка...</div>
                  </div>
                ) : orders.length === 0 ? (
                  <div className="text-center py-12">
                    <Package className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">Заказы не найдены</p>
                  </div>
                ) : (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID заказа</TableHead>
                          <TableHead>Товар</TableHead>
                          <TableHead>Количество</TableHead>
                          <TableHead>Сумма</TableHead>
                          <TableHead>Статус</TableHead>
                          <TableHead>Дата</TableHead>
                          <TableHead className="text-right">Действия</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {orders.map((order: Order) => (
                          <TableRow key={order.id} data-testid={`row-order-${order.id}`}>
                            <TableCell className="font-mono text-sm" data-testid={`cell-order-id-${order.id}`}>
                              {order.id.slice(0, 8)}
                            </TableCell>
                            <TableCell data-testid={`cell-product-id-${order.id}`}>{order.productId}</TableCell>
                            <TableCell data-testid={`cell-quantity-${order.id}`}>{order.quantity}</TableCell>
                            <TableCell className="font-semibold" data-testid={`cell-amount-${order.id}`}>
                              {order.finalAmount} ₽
                            </TableCell>
                            <TableCell>
                              <Badge
                                variant={
                                  order.paymentStatus === "delivered"
                                    ? "default"
                                    : order.paymentStatus === "cancelled"
                                    ? "destructive"
                                    : "secondary"
                                }
                                data-testid={`badge-status-${order.id}`}
                              >
                                {order.paymentStatus}
                              </Badge>
                            </TableCell>
                            <TableCell data-testid={`cell-date-${order.id}`}>
                              {format(new Date(order.createdAt), "d MMM yyyy", { locale: ru })}
                            </TableCell>
                            <TableCell className="text-right">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleOrderStatusChange(order)}
                                data-testid={`button-edit-order-${order.id}`}
                              >
                                <Edit2 className="w-4 h-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Аналитика</CardTitle>
                <CardDescription>Полный дашборд с метриками и графиками</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-3xl font-bold" data-testid="text-total-products">{products.length}</div>
                      <p className="text-xs text-muted-foreground">Всего товаров</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-3xl font-bold" data-testid="text-total-users">{users.length}</div>
                      <p className="text-xs text-muted-foreground">Всего пользователей</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-3xl font-bold" data-testid="text-total-orders">{orders.length}</div>
                      <p className="text-xs text-muted-foreground">Всего заказов</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-3xl font-bold" data-testid="text-total-revenue">
                        {(totalRevenue / 1000).toFixed(0)}K
                      </div>
                      <p className="text-xs text-muted-foreground">Выручка (₽)</p>
                    </CardContent>
                  </Card>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Статусы заказов</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Доставлено</span>
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-2 bg-green-200 rounded" style={{ width: `${deliveredOrders * 20}px` }}></div>
                          <span className="text-sm font-semibold" data-testid="text-delivered">{deliveredOrders}</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">В обработке</span>
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-2 bg-blue-200 rounded" style={{ width: `${processingOrders * 20}px` }}></div>
                          <span className="text-sm font-semibold" data-testid="text-processing">{processingOrders}</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Ожидание</span>
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-2 bg-yellow-200 rounded" style={{ width: `${(orders.length - deliveredOrders - processingOrders) * 20}px` }}></div>
                          <span className="text-sm font-semibold" data-testid="text-pending">
                            {orders.length - deliveredOrders - processingOrders}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Статусы товаров</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                          <span className="text-sm">Активные</span>
                        </div>
                        <span className="font-semibold" data-testid="text-active-products">
                          {products.filter((p: any) => p.isActive).length}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 bg-gray-400 rounded-full"></div>
                          <span className="text-sm">Неактивные</span>
                        </div>
                        <span className="font-semibold" data-testid="text-inactive-products">
                          {products.filter((p: any) => !p.isActive).length}
                        </span>
                      </div>
                      <div className="flex items-center justify-between mt-4 pt-4 border-t">
                        <span className="text-sm text-muted-foreground">Низкий запас (&lt;10)</span>
                        <span className="font-semibold text-orange-600" data-testid="text-low-stock">
                          {products.filter((p: any) => p.stock < 10).length}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Последние заказы</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {orders.length === 0 ? (
                      <p className="text-muted-foreground text-sm">Нет заказов</p>
                    ) : (
                      <div className="space-y-2">
                        {orders.slice(-5).reverse().map((order: Order) => (
                          <div key={order.id} className="flex justify-between items-center p-2 hover:bg-muted rounded">
                            <span className="text-sm font-mono">#{order.id.slice(0, 8)}</span>
                            <span className="text-sm">{order.finalAmount} ₽</span>
                            <Badge variant="outline" className="text-xs">{order.paymentStatus}</Badge>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="mt-6">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Управление контентом сайта</CardTitle>
                  <CardDescription>Правки текста, баннеров, SEO и описаний</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-semibold mb-2">Главный баннер</h3>
                      <p className="text-sm text-muted-foreground mb-2">Основное изображение на странице</p>
                      <div className="bg-muted p-4 rounded-lg">
                        <Button variant="outline" className="w-full" data-testid="button-edit-banner">
                          Редактировать баннер
                        </Button>
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <h3 className="font-semibold mb-2">SEO метаданные</h3>
                      <div className="space-y-3">
                        <div>
                          <Label className="text-sm">Заголовок страницы</Label>
                          <Input 
                            placeholder="НУ-100 и НУ-30 - Профессиональное оборудование" 
                            defaultValue={siteSettings.find((s: any) => s.key === "seo_title")?.value || ""}
                            onChange={(e) => {
                              // Will add mutation for updating settings
                            }}
                          />
                        </div>
                        <div>
                          <Label className="text-sm">Описание</Label>
                          <Input 
                            placeholder="Высокопроизводительное оборудование для промышленного применения"
                            defaultValue={siteSettings.find((s: any) => s.key === "seo_description")?.value || ""}
                            onChange={(e) => {
                              // Will add mutation for updating settings
                            }}
                          />
                        </div>
                        <div>
                          <Label className="text-sm">Ключевые слова</Label>
                          <Input 
                            placeholder="оборудование, нагрузка, промышленность"
                            defaultValue={siteSettings.find((s: any) => s.key === "seo_keywords")?.value || ""}
                            onChange={(e) => {
                              // Will add mutation for updating settings
                            }}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <h3 className="font-semibold mb-2">Описание товаров</h3>
                      <div className="space-y-3">
                        {products.map(product => (
                          <div key={product.id} className="border rounded-lg p-3">
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-medium text-sm">{product.name}</span>
                              <Button size="sm" variant="ghost" data-testid={`button-edit-product-desc-${product.id}`}>
                                <Edit2 className="w-3 h-3" />
                              </Button>
                            </div>
                            <p className="text-xs text-muted-foreground">{product.specifications}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <h3 className="font-semibold mb-2">Контактные данные</h3>
                      <div className="space-y-3">
                        <div>
                          <Label className="text-sm">Email</Label>
                          <Input 
                            placeholder="support@example.com"
                            defaultValue={siteSettings.find((s: any) => s.key === "contact_email")?.value || ""}
                            onChange={(e) => {
                              // Will add mutation for updating settings
                            }}
                          />
                        </div>
                        <div>
                          <Label className="text-sm">Телефон</Label>
                          <Input 
                            placeholder="+7 (999) 123-45-67"
                            defaultValue={siteSettings.find((s: any) => s.key === "contact_phone")?.value || ""}
                            onChange={(e) => {
                              // Will add mutation for updating settings
                            }}
                          />
                        </div>
                        <div>
                          <Label className="text-sm">Адрес</Label>
                          <Input 
                            placeholder="Москва, ул. Примерная, д. 1"
                            defaultValue={siteSettings.find((s: any) => s.key === "contact_address")?.value || ""}
                            onChange={(e) => {
                              // Will add mutation for updating settings
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Системные настройки</CardTitle>
                  <CardDescription>Конфигурация платформы</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="text-xs text-muted-foreground">Версия API</p>
                      <p className="font-semibold">v1.0.0</p>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="text-xs text-muted-foreground">База данных</p>
                      <p className="font-semibold">PostgreSQL</p>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="text-xs text-muted-foreground">Статус</p>
                      <p className="font-semibold text-green-600">Активно</p>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <p className="text-xs text-muted-foreground">Последнее обновление</p>
                      <p className="font-semibold text-xs">Сегодня</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="contacts" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Управление заявками</CardTitle>
                <CardDescription>Просмотр и управление заявками с сайта</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingContacts ? (
                  <div className="text-center py-12">
                    <div className="animate-pulse">Загрузка...</div>
                  </div>
                ) : contacts.length === 0 ? (
                  <div className="text-center py-12">
                    <Mail className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">Заявки не найдены</p>
                  </div>
                ) : (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Имя</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Телефон</TableHead>
                          <TableHead>Компания</TableHead>
                          <TableHead>Дата</TableHead>
                          <TableHead className="text-right">Действия</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {contacts.map((contact: ContactSubmission) => (
                          <TableRow key={contact.id}>
                            <TableCell className="font-medium">{contact.name}</TableCell>
                            <TableCell>{contact.email}</TableCell>
                            <TableCell>{contact.phone}</TableCell>
                            <TableCell>{contact.company}</TableCell>
                            <TableCell>{format(new Date(contact.createdAt), "d MMM yyyy", { locale: ru })}</TableCell>
                            <TableCell className="text-right">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => {
                                  deleteContact.mutate(contact.id);
                                }}
                                disabled={deleteContact.isPending}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="promocodes" className="mt-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Управление промокодами</CardTitle>
                    <CardDescription>Создание и управление промокодами</CardDescription>
                  </div>
                  <Button onClick={() => {
                    setNewPromoCode({ code: "", discountPercent: 0, expiresAt: "", isActive: true });
                    setShowCreatePromoDialog(true);
                  }}>
                    <Plus className="w-4 h-4 mr-2" />
                    Создать промокод
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {isLoadingPromoCodes ? (
                  <div className="text-center py-12">
                    <div className="animate-pulse">Загрузка...</div>
                  </div>
                ) : promoCodes.length === 0 ? (
                  <div className="text-center py-12">
                    <Tag className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">Промокоды не найдены</p>
                  </div>
                ) : (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Код</TableHead>
                          <TableHead>Скидка</TableHead>
                          <TableHead>Истекает</TableHead>
                          <TableHead>Статус</TableHead>
                          <TableHead className="text-right">Действия</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {promoCodes.map((promo: PromoCode) => (
                          <TableRow key={promo.id}>
                            <TableCell className="font-medium font-mono">{promo.code}</TableCell>
                            <TableCell>{promo.discountPercent}%</TableCell>
                            <TableCell>
                              {promo.expiresAt ? format(new Date(promo.expiresAt), "d MMM yyyy", { locale: ru }) : "Без ограничений"}
                            </TableCell>
                            <TableCell>
                              <Badge variant={promo.isActive ? "default" : "secondary"}>
                                {promo.isActive ? "Активен" : "Неактивен"}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => {
                                  deletePromoCode.mutate(promo.id);
                                }}
                                disabled={deletePromoCode.isPending}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="admins" className="mt-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Управление администраторами</CardTitle>
                    <CardDescription>Создание и управление административными аккаунтами</CardDescription>
                  </div>
                  {userData?.role === "superadmin" && (
                    <Button onClick={() => setShowCreateAdminDialog(true)}>
                      <Plus className="w-4 h-4 mr-2" />
                      Создать администратора
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Email</TableHead>
                        <TableHead>Имя</TableHead>
                        <TableHead>Роль</TableHead>
                        <TableHead>Дата создания</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users.filter((u: any) => u.role === "admin" || u.role === "superadmin" || u.role === "moderator").map((admin: any) => (
                        <TableRow key={admin.id}>
                          <TableCell className="font-medium">{admin.email}</TableCell>
                          <TableCell>
                            {admin.firstName && admin.lastName
                              ? `${admin.firstName} ${admin.lastName}`
                              : "—"}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{admin.role}</Badge>
                          </TableCell>
                          <TableCell>{format(new Date(admin.createdAt), "d MMM yyyy", { locale: ru })}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent data-testid="dialog-delete-products">
          <DialogHeader>
            <DialogTitle>Подтверждение удаления</DialogTitle>
            <DialogDescription>
              Вы уверены, что хотите удалить {selectedProducts.size} товар(ов)? Это действие нельзя отменить.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Отмена
            </Button>
            <Button variant="destructive" onClick={confirmBulkDelete} disabled={deleteProducts.isPending} data-testid="button-confirm-delete">
              {deleteProducts.isPending ? "Удаление..." : "Удалить"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={orderStatusDialog} onOpenChange={setOrderStatusDialog}>
        <DialogContent data-testid="dialog-order-status">
          <DialogHeader>
            <DialogTitle>Изменить статус заказа</DialogTitle>
            <DialogDescription>
              Заказ #{selectedOrderDetail?.id.slice(0, 8)}
            </DialogDescription>
          </DialogHeader>

          {selectedOrderDetail && (
            <div className="space-y-4">
              <div className="bg-muted p-3 rounded text-sm">
                <p className="text-muted-foreground">Текущий статус: <span className="font-semibold">{selectedOrderDetail.paymentStatus}</span></p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Новый статус</Label>
                <Select value={newOrderStatus} onValueChange={setNewOrderStatus}>
                  <SelectTrigger data-testid="select-order-status">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Ожидание оплаты</SelectItem>
                    <SelectItem value="paid">Оплачен</SelectItem>
                    <SelectItem value="processing">В обработке</SelectItem>
                    <SelectItem value="shipped">Отправлен</SelectItem>
                    <SelectItem value="delivered">Доставлен</SelectItem>
                    <SelectItem value="cancelled">Отменен</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setOrderStatusDialog(false)}>
              Отмена
            </Button>
            <Button onClick={confirmOrderStatusChange} disabled={updateOrderStatus.isPending} data-testid="button-confirm-order-status">
              {updateOrderStatus.isPending ? "Обновление..." : "Обновить"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showPriceDialog} onOpenChange={setShowPriceDialog}>
        <DialogContent data-testid="dialog-edit-price">
          <DialogHeader>
            <DialogTitle>Редактировать цену товара</DialogTitle>
            <DialogDescription>
              {selectedEditProduct?.name}
            </DialogDescription>
          </DialogHeader>

          {selectedEditProduct && (
            <div className="space-y-4">
              <div className="bg-muted p-3 rounded text-sm">
                <p className="text-muted-foreground">Текущая цена: <span className="font-semibold">{selectedEditProduct.price} ₽</span></p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="price">Новая цена (₽)</Label>
                <Input
                  type="number"
                  value={newProductPrice}
                  onChange={(e) => setNewProductPrice(e.target.value)}
                  placeholder="Введите цену"
                  min="0"
                  data-testid="input-new-price"
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPriceDialog(false)}>
              Отмена
            </Button>
            <Button 
              onClick={() => {
                if (selectedEditProduct && newProductPrice) {
                  updateProductPrice.mutate({ id: selectedEditProduct.id, price: newProductPrice });
                }
              }} 
              disabled={updateProductPrice.isPending || !newProductPrice}
              data-testid="button-confirm-price"
            >
              {updateProductPrice.isPending ? "Обновление..." : "Обновить"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showAddProductDialog} onOpenChange={setShowAddProductDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Добавить товар</DialogTitle>
            <DialogDescription>Заполните информацию о новом товаре</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Название *</Label>
              <Input
                id="name"
                value={newProduct.name}
                onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                placeholder="Название товара"
              />
            </div>
            <div>
              <Label htmlFor="sku">Артикул *</Label>
              <Input
                id="sku"
                value={newProduct.sku}
                onChange={(e) => setNewProduct({ ...newProduct, sku: e.target.value })}
                placeholder="SKU"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="price">Цена (₽) *</Label>
                <Input
                  id="price"
                  type="number"
                  value={newProduct.price}
                  onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
                  placeholder="0"
                  min="0"
                />
              </div>
              <div>
                <Label htmlFor="stock">Количество *</Label>
                <Input
                  id="stock"
                  type="number"
                  value={newProduct.stock}
                  onChange={(e) => setNewProduct({ ...newProduct, stock: parseInt(e.target.value) || 0 })}
                  placeholder="0"
                  min="0"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="description">Описание</Label>
              <Textarea
                id="description"
                value={newProduct.description}
                onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                placeholder="Описание товара"
                rows={3}
              />
            </div>
            <div>
              <Label htmlFor="specifications">Характеристики</Label>
              <Textarea
                id="specifications"
                value={newProduct.specifications}
                onChange={(e) => setNewProduct({ ...newProduct, specifications: e.target.value })}
                placeholder="Технические характеристики"
                rows={3}
              />
            </div>
            <div>
              <Label htmlFor="category">Категория</Label>
              <Input
                id="category"
                value={newProduct.category}
                onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
                placeholder="Категория"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="isActive"
                checked={newProduct.isActive}
                onCheckedChange={(checked) => setNewProduct({ ...newProduct, isActive: checked as boolean })}
              />
              <Label htmlFor="isActive">Активен</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddProductDialog(false)}>
              Отмена
            </Button>
            <Button
              onClick={() => {
                if (newProduct.name && newProduct.price && newProduct.sku) {
                  createProduct.mutate(newProduct);
                } else {
                  toast({
                    title: "Ошибка",
                    description: "Заполните все обязательные поля",
                    variant: "destructive",
                  });
                }
              }}
              disabled={createProduct.isPending}
            >
              {createProduct.isPending ? "Создание..." : "Создать"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showEditProductDialog} onOpenChange={setShowEditProductDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Редактировать товар</DialogTitle>
            <DialogDescription>Обновите информацию о товаре</DialogDescription>
          </DialogHeader>
          {editingProduct && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit-name">Название *</Label>
                <Input
                  id="edit-name"
                  value={editingProduct.name || ""}
                  onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="edit-sku">Артикул *</Label>
                <Input
                  id="edit-sku"
                  value={editingProduct.sku || ""}
                  onChange={(e) => setEditingProduct({ ...editingProduct, sku: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-price">Цена (₽) *</Label>
                  <Input
                    id="edit-price"
                    type="number"
                    value={editingProduct.price || ""}
                    onChange={(e) => setEditingProduct({ ...editingProduct, price: e.target.value })}
                    min="0"
                  />
                </div>
                <div>
                  <Label htmlFor="edit-stock">Количество *</Label>
                  <Input
                    id="edit-stock"
                    type="number"
                    value={editingProduct.stock || 0}
                    onChange={(e) => setEditingProduct({ ...editingProduct, stock: parseInt(e.target.value) || 0 })}
                    min="0"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="edit-description">Описание</Label>
                <Textarea
                  id="edit-description"
                  value={editingProduct.description || ""}
                  onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="edit-specifications">Характеристики</Label>
                <Textarea
                  id="edit-specifications"
                  value={editingProduct.specifications || ""}
                  onChange={(e) => setEditingProduct({ ...editingProduct, specifications: e.target.value })}
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="edit-category">Категория</Label>
                <Input
                  id="edit-category"
                  value={editingProduct.category || ""}
                  onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value })}
                />
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="edit-isActive"
                  checked={editingProduct.isActive !== undefined ? editingProduct.isActive : true}
                  onCheckedChange={(checked) => setEditingProduct({ ...editingProduct, isActive: checked as boolean })}
                />
                <Label htmlFor="edit-isActive">Активен</Label>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditProductDialog(false)}>
              Отмена
            </Button>
            <Button
              onClick={() => {
                if (editingProduct && editingProduct.name && editingProduct.price && editingProduct.sku) {
                  updateProduct.mutate(editingProduct);
                }
              }}
              disabled={updateProduct.isPending}
            >
              {updateProduct.isPending ? "Обновление..." : "Обновить"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showCreateAdminDialog} onOpenChange={setShowCreateAdminDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Создать администратора</DialogTitle>
            <DialogDescription>Создайте новый административный аккаунт</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="admin-email">Email *</Label>
              <Input
                id="admin-email"
                type="email"
                value={newAdmin.email}
                onChange={(e) => setNewAdmin({ ...newAdmin, email: e.target.value })}
                placeholder="admin@example.com"
              />
            </div>
            <div>
              <Label htmlFor="admin-password">Пароль *</Label>
              <Input
                id="admin-password"
                type="password"
                value={newAdmin.password}
                onChange={(e) => setNewAdmin({ ...newAdmin, password: e.target.value })}
                placeholder="Минимум 8 символов"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="admin-firstname">Имя</Label>
                <Input
                  id="admin-firstname"
                  value={newAdmin.firstName}
                  onChange={(e) => setNewAdmin({ ...newAdmin, firstName: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="admin-lastname">Фамилия</Label>
                <Input
                  id="admin-lastname"
                  value={newAdmin.lastName}
                  onChange={(e) => setNewAdmin({ ...newAdmin, lastName: e.target.value })}
                />
              </div>
            </div>
            <div>
              <Label htmlFor="admin-role">Роль</Label>
              <Select value={newAdmin.role} onValueChange={(value) => setNewAdmin({ ...newAdmin, role: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Администратор</SelectItem>
                  <SelectItem value="moderator">Модератор</SelectItem>
                  {userData?.role === "superadmin" && <SelectItem value="superadmin">Супер-администратор</SelectItem>}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateAdminDialog(false)}>
              Отмена
            </Button>
            <Button
              onClick={() => {
                if (newAdmin.email && newAdmin.password) {
                  createAdmin.mutate(newAdmin);
                } else {
                  toast({
                    title: "Ошибка",
                    description: "Заполните email и пароль",
                    variant: "destructive",
                  });
                }
              }}
              disabled={createAdmin.isPending}
            >
              {createAdmin.isPending ? "Создание..." : "Создать"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showUserRoleDialog} onOpenChange={setShowUserRoleDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Изменить роль пользователя</DialogTitle>
            <DialogDescription>
              {selectedUserForRole && `Пользователь: ${selectedUserForRole.email}`}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="user-role">Роль</Label>
              <Select value={newUserRole} onValueChange={setNewUserRole}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">Пользователь</SelectItem>
                  <SelectItem value="moderator">Модератор</SelectItem>
                  <SelectItem value="admin">Администратор</SelectItem>
                  {userData?.role === "superadmin" && <SelectItem value="superadmin">Супер-администратор</SelectItem>}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowUserRoleDialog(false)}>
              Отмена
            </Button>
            <Button
              onClick={() => {
                if (selectedUserForRole && newUserRole) {
                  updateUserRole.mutate({ userId: selectedUserForRole.id, role: newUserRole });
                }
              }}
              disabled={updateUserRole.isPending}
            >
              {updateUserRole.isPending ? "Обновление..." : "Обновить"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showCreatePromoDialog} onOpenChange={setShowCreatePromoDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Создать промокод</DialogTitle>
            <DialogDescription>Создайте новый промокод для скидок</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="promo-code">Код промокода *</Label>
              <Input
                id="promo-code"
                value={newPromoCode.code}
                onChange={(e) => setNewPromoCode({ ...newPromoCode, code: e.target.value.toUpperCase() })}
                placeholder="PROMO2024"
              />
            </div>
            <div>
              <Label htmlFor="promo-discount">Скидка (%) *</Label>
              <Input
                id="promo-discount"
                type="number"
                value={newPromoCode.discountPercent}
                onChange={(e) => setNewPromoCode({ ...newPromoCode, discountPercent: parseInt(e.target.value) || 0 })}
                placeholder="10"
                min="0"
                max="100"
              />
            </div>
            <div>
              <Label htmlFor="promo-expires">Дата истечения</Label>
              <Input
                id="promo-expires"
                type="datetime-local"
                value={newPromoCode.expiresAt}
                onChange={(e) => setNewPromoCode({ ...newPromoCode, expiresAt: e.target.value })}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="promo-active"
                checked={newPromoCode.isActive}
                onCheckedChange={(checked) => setNewPromoCode({ ...newPromoCode, isActive: checked as boolean })}
              />
              <Label htmlFor="promo-active">Активен</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreatePromoDialog(false)}>
              Отмена
            </Button>
            <Button
              onClick={() => {
                if (newPromoCode.code && newPromoCode.discountPercent > 0) {
                  createPromoCode.mutate({
                    code: newPromoCode.code,
                    discountPercent: newPromoCode.discountPercent,
                    expiresAt: newPromoCode.expiresAt || undefined,
                    isActive: newPromoCode.isActive,
                  });
                  setShowCreatePromoDialog(false);
                  setNewPromoCode({ code: "", discountPercent: 0, expiresAt: "", isActive: true });
                } else {
                  toast({
                    title: "Ошибка",
                    description: "Заполните код и укажите скидку",
                    variant: "destructive",
                  });
                }
              }}
              disabled={createPromoCode.isPending}
            >
              {createPromoCode.isPending ? "Создание..." : "Создать"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
