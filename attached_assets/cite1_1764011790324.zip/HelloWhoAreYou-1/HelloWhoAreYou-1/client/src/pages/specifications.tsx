export default function Specifications() {
  return (
    <div className="container mx-auto px-4 py-8 pt-24">
      <h1 className="text-4xl font-bold mb-8">Характеристики</h1>
      <div className="prose max-w-none">
        <p>Страница с характеристиками товаров</p>
      </div>
    </div>
  );
}

